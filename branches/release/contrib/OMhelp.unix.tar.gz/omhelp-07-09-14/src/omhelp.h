/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ACCENT_lex = 258,
     AINDEX_lex = 259,
     ALIGN_lex = 260,
     BEGIN_lex = 261,
     BGCOLOR_lex = 262,
     BIG_lex = 263,
     BOLD_lex = 264,
     CEND_lex = 265,
     CENTER_lex = 266,
     CHILDREN_lex = 267,
     CHILDTABLE_lex = 268,
     CINDEX_lex = 269,
     CMARK_lex = 270,
     CNEXT_lex = 271,
     CODE_lex = 272,
     CODECOLOR_lex = 273,
     CODEP_lex = 274,
     COMMENT_lex = 275,
     CONTENTS_lex = 276,
     CREF_lex = 277,
     DATE_lex = 278,
     DOLLAR_lex = 279,
     DOUBLE_DOLLAR_lex = 280,
     END_lex = 281,
     EOF_lex = 282,
     ERRORCOLOR_lex = 283,
     ESCAPE_lex = 284,
     EXECUTE_lex = 285,
     FEND_lex = 286,
     FIXED_lex = 287,
     HEAD_lex = 288,
     HREF_lex = 289,
     ICON_lex = 290,
     IMAGE_lex = 291,
     INCLUDE_lex = 292,
     INDEX_lex = 293,
     ITALIC_lex = 294,
     LATEX_lex = 295,
     LEND_lex = 296,
     LIST_lex = 297,
     LNEXT_lex = 298,
     MATH_lex = 299,
     MINDEX_lex = 300,
     MREF_lex = 301,
     NAVIGATE_lex = 302,
     NEWLINECH_lex = 303,
     NOBREAK_lex = 304,
     NOSPELL_lex = 305,
     NUMBER_lex = 306,
     PATH_lex = 307,
     PRE_lex = 308,
     REND_lex = 309,
     RMARK_lex = 310,
     RNEXT_lex = 311,
     RREF_lex = 312,
     SECTION_lex = 313,
     SKIPNL_lex = 314,
     SMALL_lex = 315,
     SPELL_lex = 316,
     SUBHEAD_lex = 317,
     SYNTAX_lex = 318,
     TABLE_lex = 319,
     TABSIZE_lex = 320,
     TEND_lex = 321,
     TEXT_lex = 322,
     TEXTCOLOR_lex = 323,
     TH_lex = 324,
     TITLE_lex = 325,
     TRACE_lex = 326,
     TREF_lex = 327,
     VERBATIM_lex = 328,
     WSPACE_lex = 329,
     XREF_lex = 330
   };
#endif
/* Tokens.  */
#define ACCENT_lex 258
#define AINDEX_lex 259
#define ALIGN_lex 260
#define BEGIN_lex 261
#define BGCOLOR_lex 262
#define BIG_lex 263
#define BOLD_lex 264
#define CEND_lex 265
#define CENTER_lex 266
#define CHILDREN_lex 267
#define CHILDTABLE_lex 268
#define CINDEX_lex 269
#define CMARK_lex 270
#define CNEXT_lex 271
#define CODE_lex 272
#define CODECOLOR_lex 273
#define CODEP_lex 274
#define COMMENT_lex 275
#define CONTENTS_lex 276
#define CREF_lex 277
#define DATE_lex 278
#define DOLLAR_lex 279
#define DOUBLE_DOLLAR_lex 280
#define END_lex 281
#define EOF_lex 282
#define ERRORCOLOR_lex 283
#define ESCAPE_lex 284
#define EXECUTE_lex 285
#define FEND_lex 286
#define FIXED_lex 287
#define HEAD_lex 288
#define HREF_lex 289
#define ICON_lex 290
#define IMAGE_lex 291
#define INCLUDE_lex 292
#define INDEX_lex 293
#define ITALIC_lex 294
#define LATEX_lex 295
#define LEND_lex 296
#define LIST_lex 297
#define LNEXT_lex 298
#define MATH_lex 299
#define MINDEX_lex 300
#define MREF_lex 301
#define NAVIGATE_lex 302
#define NEWLINECH_lex 303
#define NOBREAK_lex 304
#define NOSPELL_lex 305
#define NUMBER_lex 306
#define PATH_lex 307
#define PRE_lex 308
#define REND_lex 309
#define RMARK_lex 310
#define RNEXT_lex 311
#define RREF_lex 312
#define SECTION_lex 313
#define SKIPNL_lex 314
#define SMALL_lex 315
#define SPELL_lex 316
#define SUBHEAD_lex 317
#define SYNTAX_lex 318
#define TABLE_lex 319
#define TABSIZE_lex 320
#define TEND_lex 321
#define TEXT_lex 322
#define TEXTCOLOR_lex 323
#define TH_lex 324
#define TITLE_lex 325
#define TRACE_lex 326
#define TREF_lex 327
#define VERBATIM_lex 328
#define WSPACE_lex 329
#define XREF_lex 330




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE omhlval;

