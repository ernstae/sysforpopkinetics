# ifndef AUTO_TAG_INCLUDED
# define AUTO_TAG_INCLUDED

# define SEARCH_TAG         "_search"     
# define EXTERNAL_TAG       "_external"
# define INDEX_TAG          "_index"
# define CONTENTS_TAG       "_contents"
# define REFERENCE_TAG      "_reference"
# define PRINTABLE_TAG      "_printable"

# endif
