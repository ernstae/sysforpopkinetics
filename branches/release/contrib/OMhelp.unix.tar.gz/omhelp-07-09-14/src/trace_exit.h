# ifndef TRACE_EXIT_INCLUDED
# define TRACE_EXIT_INCLUDED

extern void trace_exit(int status);

# endif
