# ifndef LATEX_MACRO_INCLUDED
# define LATEX_MACRO_INCLUDED

// BEGIN SHORT COPYRIGHT
/* -----------------------------------------------------------------------
OMhelp: Source Code -> Help Files: Copyright (C) 1998-2004 Bradley M. Bell

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
------------------------------------------------------------------------ */
// END SHORT COPYRIGHT
/*
$begin LatexMacro$$

$section Implementation of Latex Macro Preprocessor$$

$contents/
	LatexMacro.c/$$

$end
*/

extern void        LatexMacroUserInput(int line, const char *input);
extern void        LatexMacroFree();
extern char        LatexMacroGetCh(void);
extern int         LatexMacroInputLine(void);
extern const char *LatexMacroInputFile(void);
extern const char *LatexMacroExpandInput(void);
extern int         LatexMacroExpandLine(void);
extern const char *LatexMacroExpandFile(void);
extern const char *LatexMacroExpandName(void);
extern void        LatexMacroKeep(void);

# endif
