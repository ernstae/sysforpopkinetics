/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0

/* Substitute the variable and function names.  */
#define yyparse omhparse
#define yylex   omhlex
#define yyerror omherror
#define yylval  omhlval
#define yychar  omhchar
#define yydebug omhdebug
#define yynerrs omhnerrs


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ACCENT_lex = 258,
     AINDEX_lex = 259,
     ALIGN_lex = 260,
     BEGIN_lex = 261,
     BGCOLOR_lex = 262,
     BIG_lex = 263,
     BOLD_lex = 264,
     CEND_lex = 265,
     CENTER_lex = 266,
     CHILDREN_lex = 267,
     CHILDTABLE_lex = 268,
     CINDEX_lex = 269,
     CMARK_lex = 270,
     CNEXT_lex = 271,
     CODE_lex = 272,
     CODECOLOR_lex = 273,
     CODEP_lex = 274,
     COMMENT_lex = 275,
     CONTENTS_lex = 276,
     CREF_lex = 277,
     DATE_lex = 278,
     DOLLAR_lex = 279,
     DOUBLE_DOLLAR_lex = 280,
     END_lex = 281,
     EOF_lex = 282,
     ERRORCOLOR_lex = 283,
     ESCAPE_lex = 284,
     EXECUTE_lex = 285,
     FEND_lex = 286,
     FIXED_lex = 287,
     HEAD_lex = 288,
     HREF_lex = 289,
     ICON_lex = 290,
     IMAGE_lex = 291,
     INCLUDE_lex = 292,
     INDEX_lex = 293,
     ITALIC_lex = 294,
     LATEX_lex = 295,
     LEND_lex = 296,
     LIST_lex = 297,
     LNEXT_lex = 298,
     MATH_lex = 299,
     MINDEX_lex = 300,
     MREF_lex = 301,
     NAVIGATE_lex = 302,
     NEWLINECH_lex = 303,
     NOBREAK_lex = 304,
     NOSPELL_lex = 305,
     NUMBER_lex = 306,
     PATH_lex = 307,
     PRE_lex = 308,
     REND_lex = 309,
     RMARK_lex = 310,
     RNEXT_lex = 311,
     RREF_lex = 312,
     SECTION_lex = 313,
     SKIPNL_lex = 314,
     SMALL_lex = 315,
     SPELL_lex = 316,
     SUBHEAD_lex = 317,
     SYNTAX_lex = 318,
     TABLE_lex = 319,
     TABSIZE_lex = 320,
     TEND_lex = 321,
     TEXT_lex = 322,
     TEXTCOLOR_lex = 323,
     TH_lex = 324,
     TITLE_lex = 325,
     TRACE_lex = 326,
     TREF_lex = 327,
     VERBATIM_lex = 328,
     WSPACE_lex = 329,
     XREF_lex = 330
   };
#endif
/* Tokens.  */
#define ACCENT_lex 258
#define AINDEX_lex 259
#define ALIGN_lex 260
#define BEGIN_lex 261
#define BGCOLOR_lex 262
#define BIG_lex 263
#define BOLD_lex 264
#define CEND_lex 265
#define CENTER_lex 266
#define CHILDREN_lex 267
#define CHILDTABLE_lex 268
#define CINDEX_lex 269
#define CMARK_lex 270
#define CNEXT_lex 271
#define CODE_lex 272
#define CODECOLOR_lex 273
#define CODEP_lex 274
#define COMMENT_lex 275
#define CONTENTS_lex 276
#define CREF_lex 277
#define DATE_lex 278
#define DOLLAR_lex 279
#define DOUBLE_DOLLAR_lex 280
#define END_lex 281
#define EOF_lex 282
#define ERRORCOLOR_lex 283
#define ESCAPE_lex 284
#define EXECUTE_lex 285
#define FEND_lex 286
#define FIXED_lex 287
#define HEAD_lex 288
#define HREF_lex 289
#define ICON_lex 290
#define IMAGE_lex 291
#define INCLUDE_lex 292
#define INDEX_lex 293
#define ITALIC_lex 294
#define LATEX_lex 295
#define LEND_lex 296
#define LIST_lex 297
#define LNEXT_lex 298
#define MATH_lex 299
#define MINDEX_lex 300
#define MREF_lex 301
#define NAVIGATE_lex 302
#define NEWLINECH_lex 303
#define NOBREAK_lex 304
#define NOSPELL_lex 305
#define NUMBER_lex 306
#define PATH_lex 307
#define PRE_lex 308
#define REND_lex 309
#define RMARK_lex 310
#define RNEXT_lex 311
#define RREF_lex 312
#define SECTION_lex 313
#define SKIPNL_lex 314
#define SMALL_lex 315
#define SPELL_lex 316
#define SUBHEAD_lex 317
#define SYNTAX_lex 318
#define TABLE_lex 319
#define TABSIZE_lex 320
#define TEND_lex 321
#define TEXT_lex 322
#define TEXTCOLOR_lex 323
#define TH_lex 324
#define TITLE_lex 325
#define TRACE_lex 326
#define TREF_lex 327
#define VERBATIM_lex 328
#define WSPACE_lex 329
#define XREF_lex 330




/* Copy the first part of user declarations.  */
#line 18 "omhelp.y"

/*

Tag2Title(tag)
Returns a pointer to a character vector containing the title
for the section with the specified cross reference tag,
where ~tag is a '\0' terminated character row vector.
If there is no section with the specificed
cross reference tag, NULL is returned.
*/

# include "Color.h"
# include "InitParser.h"
# include "Tag2Title.h"

# include <stdio.h>
# include <ctype.h>
# include <string.h>
# include <stdlib.h>
# include <assert.h>
# include <time.h>

# include "FrameSet.h"
# include "HtmlHead.h"
# include "relative.h"
# include "style.h"
# include "LatexMacro.h"
# include "content.h"
# include "AutomaticLink.h"
# include "omhparse.h"
# include "allocmem.h"
# include "strjoin.h"
# include "str_alloc.h"
# include "input.h"
# include "output.h"
# include "spell.h"
# include "copyfile.h"
# include "fatalerr.h"
# include "execute.h"
# include "pending.h"
# include "math.h"
# include "convert.h"
# include "SplitText.h"
# include "section.h"
# include "children.h"
# include "search.h"
# include "href.h"
# include "index.h"
# include "funref.h"
# include "cross.h"
# include "StrLowCase.h"
# include "StrLowAlloc.h"
# include "PatternMatch.h"
# include "DirSep.h"
# include "main.h"
# include "head.h"
# include "automatic.h"
# include "StrRemove.h"
# include "ClipWhiteSpace.h"
# include "UniformWhiteSpace.h"
# include "Internal2Out.h"
# include "int2str.h"
# include "LatexLexPut.h"
# include "texparse.h"
# include "lexomh.h"
# include "AutoTag.h"

# ifndef WIN32
# define stricmp strcasecmp 
# endif


# include "OmhStype.h"
# define YYSTYPE OmhStype
# define YYDEBUG 1

# define TAB_SIZE           5
# define MAX_TAG            100
# define MAX_WORD           100
# define MAX_LIST_LEVEL     10
# define MAX_AUTOMATIC      10
# define MAX_DEPTH          100


// define in main.c
extern int  DebugOmhelp;

// ***************** Section State ***************************

// frame counter in current section
static int iFrame;

// maximum frame referenced for the current section
static int MaxFrame;
static int MaxFrameLine;
static char *MaxFrameFile = NULL;

// track pending tables
static int  TableLevel    = 0;

// track pending lists
static int  ListLevel     = 0;
static int  ListOrdered[MAX_LIST_LEVEL];

// current table alingment
static char *HorizontalAlign;
static char *VerticalAlign;

// current character that gets converted to '$'
static char Dollar;

// current character that gets converted to RESISTERED_TRADE_MARK_CHARACTER
static char Rmark;

// current character that gets converted to COPYRIGHT_CHARACTER
static char Cmark;

// current character that gets converted to a space
static char Wspace;

// current program comment character
static char NewlineCh;

// current escape character
static char Escape;

// current automatic mindex commands
static int MindexSection;
static int MindexHead;
static int MindexSubhead;

// current code font color
static char *CodeColor  = NULL;
static char *ErrorColor = NULL;

// flag that indicates spell checking is on
static int CheckSpell   = 1;

// ************************* Other Static Data  ************************

// Was previous output a heading
static int PreviousOutputWasHeading = 0;
int PreviousOmhelpOutputWasHeading()
{	return PreviousOutputWasHeading; }

// track pending execute command
static int ExecuteLine   = 0;
static char *ExecuteFile = NULL;


// track pending italic commands
static int ItalicCount = 0;

// count of section and end commands in this file
static int BeginCount;
static int EndCount;

// are we currently reading an include file
static char *IncludeFrom = NULL;
static int   IncludeLine = 0;

static int   RootHasChildren       = 0;
static SectionInfo *SectionTree    = NULL;
static SectionInfo *CurrentSection = NULL;

// Text being matched by MatchOrOutput which assumes that the first character
// ("<" in this case) appears no where else in any of the text. Thus
// one match cannot startup while another is running.
enum MatchType {
	NO_match,           // corresponds to the value 0
	HREF_match,
	CONTENTS_match,
	EXECUTE_match,
	FEND_match,
	TITLE_match,
	TREF_match,
	RREF_match,
	ENDHREF_match,
	CHILDREN_match,
	CHILDTABLE_match,
	ACCENT_match
};
	
static char *MatchText[]  = {
	"<HREF=\"", 
	"<CONTENTS>", 
	"<EXECUTE=\"", 
	"<FEND>",
	"<TITLE=\"",
	"<TREF=\"",
	"<RREF=\"",
	"</HREF>",
	"<CHILDREN>",
	"<CHILDTABLE>",
	"<ACCENT="
};
static int   MatchLen[]   = {7, 10, 10, 6,  8, 7, 7, 7, 10, 12, 8};
static int   MatchState[] = {0, 0,  0,  0, 0,  0, 0, 0, 0,  0,  0, 0};
static int   MatchNumber  = sizeof(MatchText) / sizeof(MatchText[0]);

// ***************** Static Functions ************************

static void fatal_not_2_dollar_or_text(int code_cmd1, int line1, int code_cmd2)
{	fatalomh(
		"Error in the ",
		TokenCode2String(code_cmd1),
		" command that begins in line ",
		int2str(line1), 
		".\nThis command is not terminated by $$ before ",
		TokenCode2String( code_cmd2 ),
		" appears.",
		NULL
	);
}

static int WhiteSpace(char *s)
{	int c;

	c = *s++;
	while( c != '\0' )
	{	if( ! isspace(c) )
			return 0;
		c = *s++;
	}
	return 1;
}
		

static void outtext(int line, const char *s, int pre)
{	const char *bad = NULL;
	int nchar;

	if( *s == '\0' ) return;

	if( pre )
	{	// a standard compliant way to inhibit line breaks at 
		// '-' in MS Internet Explorer (should not be necessary)
		OutputString("<span style='white-space: nowrap'>");
	}

	while( *s != '\0' )
	{	
		if( CheckSpell )
			bad = SpellingError(s, &nchar);

		if( bad == NULL )
			bad = s + strlen(s);
	
		while( s < bad )
		{	line += (*s == '\n');	
			ConvertOutputCh(*s++, pre);
		}

		assert( bad != NULL );
		if( *bad != '\0' )
		{
			assert( nchar > 0 );
			if( PostWarnings() )
			{	printf(
					"\nOMhelp Warning: spelling "
					"in line %d of file %s: ",
					line,
					InputName()
				);	
				OutputString("<font color=\"");
				OutputString(ErrorColor);
				OutputString("\">");

				while( nchar-- )
				{
					if( isspace(*s) )
						printf(" ");
					else	printf("%c", *s);

					line += (*s == '\n');	
					ConvertOutputCh(*s++, pre);
				}
				OutputString("</font>");
				printf("\n");
			}
			else	while( nchar-- )
			{
				line += (*s == '\n');	
				ConvertOutputCh(*s++, pre);
			}
		}
	}
	if( pre )
		OutputString("</span>");
}

static void OutPre(int line, const char *s)
{	outtext(line, s, 1); }




static void PushOmhInput(SectionInfo *S)
{	SectionInfo *P;
	
	int  nparent;
	
	// number of parents for this file
	nparent  = 0;
	P        = S->parent;
	while(P != NULL )
	{	nparent++;
		P = P->parent;
	}
	
	// set next input file and index nparent spaces when
	// printing its name on standard output
	InputPush(S->root, S->ext, nparent);

	BeginCount = 0;
	EndCount     = 0;
}

static void PushTmpOutput(const char *root)
{	char *file;
	file = strjoin(root, ".tmp");
	PushOutput(file);
	FreeMem(file);
}

static char MatchBuffer[10];
static int  MatchIndex = 0;
static int MatchOrOutput(int ch)
{	int    i;
	int    j;
	int    state;
	int    match;
	char   *text;

	match = 0;
	for(i = 0; i < MatchNumber; i++)
	{	text  = MatchText[i];
		state = MatchState[i];
		if( text[state] == ch )
		{	MatchState[i]++;
			if( MatchState[i] == MatchLen[i] )
			{	for(j = 0; j < MatchNumber; j++)
					MatchState[j] = 0;
				MatchIndex = 0;
				return i + 1;
			}
			match = 1;
		}
		else	MatchState[i] = 0;
	}
	if( match )
	{	assert(MatchIndex < 100);
		MatchBuffer[MatchIndex++] = ch;
		return 0;
	}
	for(i = 0; i < MatchIndex; i++)
		OutputChar(MatchBuffer[i]);			
	MatchIndex = 0;
	
	if( ch != EOF )
		OutputChar((char) ch);
	
	return 0;
}


static void SecondPass(SectionInfo *F)
{	
	char *tagLower;
	char *NameTmp;
	FILE *fpTmp;
	int  ch;
	int  match;

	// initialize to avoid warning
	// (compiler does not know it will be reset before used)
	int            lastCrossReferenceDefined = 0; 
	CrossReference *lastCrossReference = NULL;
	
	// following buffer must be enough larger than MAX_TAG
	char buffer[200];
	

	assert( RootHasChildren || F == SectionTree );

	while( F != NULL )
	{	int         HtmlOnly;
		const char *FrameOneExt;

		// only use HTML format for frame one of these sections
		HtmlOnly =  (strcmp(F->tag, SEARCH_TAG) == 0)
		         || (strcmp(F->tag, CONTENTS_TAG) == 0);
		if( HtmlOnly )
			FrameOneExt = Internal2Out("HtmlOnlyExtension");
		else	FrameOneExt = Internal2Out("OutputExtension");

		// lower case version of tag
		tagLower = F->tagLower;

		// input file
		NameTmp = strjoin(F->tag, ".tmp");
		DirSep(NameTmp);
		StrLowCase(NameTmp);

		fpTmp   = fopen(NameTmp, "r");
		if( fpTmp == NULL ) fatalerr(
			"OMhelp created the temporary file\n",
			NameTmp,
			"\nbut that file is no longer available for reading.",
			NULL
		);
		if( PrintableOmhelp() )
		{	OutputString("\n<hr");
			OutputString(Internal2Out("SelfTerminateCmd"));
			OutputString("\n");
		}
		else if( NoFrame() )
		{	// new output file for this section
			sprintf(buffer, 
				"%s%s", 
				tagLower, 
				FrameOneExt
			);
			PushOutput(buffer);

			if( HtmlOnly )
				OutputString("<html>\n");
			else	OutputString(Internal2Out("StartOutputFile"));
			OutputHtmlHead(F);
			OutputString("<body>\n");

			// relative links are in this file
			if( RootHasChildren )
				RelativeTable(F);
		}
		else
		{
			if( RootHasChildren )
				RelativeFrame(F);
			OutputFrameSet(F, FrameOneExt, RootHasChildren);
	
			// initialize user side frame index
			iFrame = 1;
			
			// create first output file
			sprintf(buffer, 
				"%s_frame%d%s", 
				tagLower, 
				iFrame,
				FrameOneExt
			);
			PushOutput(buffer);

			if( HtmlOnly )
			{
				OutputString("<html>\n");
				OutputHtmlHead(F);
				OutputString("<body>\n");
				AutomaticLink(RootHasChildren, F);
			}
			else
			{
				OutputString(Internal2Out("StartOutputFile"));
				OutputHtmlHead(F);
				OutputString("<body>\n");
				AutomaticLink(RootHasChildren, F);
			}
		}
		
		// read until end of file
		ch    = getc(fpTmp);
		while( ch != EOF )
		{	// output checking for special sequences
			match = MatchOrOutput(ch);

			// check for an accent over a vowel
			if( match == ACCENT_match ) 
			{	// convert to proper accent
				buffer[0] = getc(fpTmp);
				buffer[1] = '\0';
				FormatOutput("&%sacute;", buffer);
				ch = getc(fpTmp);
				assert( ch == '>' );
			}
			
			// check for a cross reference
			if( match == HREF_match )
			{	
				char *tag;
				int npound   = 0;
				int itag     = 0;
				int ipound[3];
				int defined;

				char *head;
				char *external;
				char *displayframe;

				CrossReference *C = NULL;
				
				tag = AllocMem(1000, sizeof(char));
				
				// get the full pass1 cross reference
				ch = getc(fpTmp);
				while( ch != '"' )
				{	if( ch == '#' )
					{	assert( npound < 3 );
						ipound[npound++] = itag;
					}
					tag[itag++] = ch;
					ch = getc(fpTmp);
					assert(itag < 1000);
				}

				// remove the matching >
				ch = getc(fpTmp);
				assert( ch == '>' );
				
				assert( npound == 3 );
				assert( ipound[0] > 0);
				assert( ipound[0] < ipound[1] );
				assert( ipound[1] < ipound[2] );
				assert( ipound[2] < itag);

				tag[ipound[0]] = '\0';
				tag[ipound[1]] = '\0';
				tag[ipound[2]] = '\0';
				tag[itag]      = '\0';

				head         = tag + ipound[0] + 1;
				external     = tag + ipound[1] + 1;
				displayframe = tag + ipound[2] + 1;
				
				defined = strcmp(external, "true") == 0;
				if( ! defined )
				{
			       		// check the cross reference
					C = FindCrossReference(tag, head);
					assert(C != NULL);

					defined = C->defined;
				}
				lastCrossReferenceDefined = defined;
				lastCrossReference        = C;
				if( defined 
				&& PrintableOmhelp() 
				&& strcmp(external, "true") != 0 )
				{	
					HrefPrintablePass2(
						C->printid 
					);
				}
				else if( defined )
				{	HrefOutputPass2(
						tag, 
						head, 
						external,
						displayframe
					);
				}
				else
				{	int matchtmp;
					// remove the cross reference 

					// put cross reference text in red
					if( PostWarnings() )
					OutputString("<u><font color=\"red\">");
					
					// read and output until find </HREF>
					matchtmp = NO_match;
					while( matchtmp != ENDHREF_match )
					{	ch       = getc(fpTmp);
						matchtmp = MatchOrOutput(ch);
					}

					// terminate red underlines font
					if( PostWarnings() )
					OutputString("</font></u>\n");
				}
				
				FreeMem(tag);
			}

			// check for table of contents
			if( match == CHILDTABLE_match )
			{	TableChildren(F, PrintableOmhelp() );
			}
			if( match == CONTENTS_match ) 
			{	ListChildren(F, PrintableOmhelp() );
			}
			if( match == CHILDREN_match )
			{	// do nothing
			}
			
			// check for execute reference
			if( match == EXECUTE_match )
			{	char *execute;
				char *lower;

				int i = 0;
				
				execute = AllocMem(1000, sizeof(char));
				ch = getc(fpTmp);
				
				while( ch != '"' )
				{	execute[i++] = ch;
					ch = getc(fpTmp);
					assert(i < 1000);
				}
				execute[i] = '\0';
				lower = StrLowAlloc(execute);

				// remove the matching >
				ch = getc(fpTmp);
				assert( ch == '>' );

				// note the color for cross reference
				// that referrs to an execute
				FormatOutput(
					"<a href=\"%s\" target=\"_top\">", 
					lower
				);
				OutputString("<font color=\"green\">");
				FormatOutput("%s</font></a>", execute);
				
				FreeMem(lower);
				FreeMem(execute);
			}

			// check for end of frame
			if( match == FEND_match )
			{
				assert( ! PrintableOmhelp() );
				assert( ! NoFrame() );

				OutputString("\n</body>\n</html>\n");
				PopOutput();

				iFrame++;
				sprintf(
					buffer, 
					"%s_frame%d%s", 
					tagLower, 
					iFrame,
					Internal2Out("OutputExtension")
				);
				PushOutput(buffer);

				OutputString(Internal2Out("StartOutputFile"));
				OutputHtmlHead(F);
				OutputString("<body>\n");

				// Automatic links to this section and frame
				AutomaticLink(0, F);
			}
	
			if( match == TREF_match || 
			    match == RREF_match ||
			    match == TITLE_match
			)
			{	char           *tag;
				int            itag;
				CrossReference *C;

				// copy tag from file
				tag  = AllocMem(1000, sizeof(char));
				itag = 0;
				ch   = getc(fpTmp);
				while( ch != '"' )
				{	tag[itag++] = ch;
					ch          = getc(fpTmp);
					assert(itag < 1000);
				}
				tag[itag] = '\0';

				// remove the matching >
				ch   = getc(fpTmp);
				assert(ch == '>');


	       			// check the cross reference
				C = FindCrossReference(tag, "");
				assert(C != NULL);

				if(! C->defined)
				{	// underline tag in red
					if( PostWarnings() )
					OutputString("<u><font color=\"red\">");

					ConvertOutputString(tag, 0);

					if( PostWarnings() )
					OutputString("</font></u>\n");
				}
				else if( match == TITLE_match )
				{	// get the corresponding title
					const char *title = Tag2Title(tag);
					assert(title != NULL);
					ConvertOutputString(title, 0);
				}
				else
				{	// get the corresponding title
					const char *title = Tag2Title(tag);
					assert(title != NULL);

					if( PrintableOmhelp() )
						HrefPrintablePass2(
							C->printid);
					else	HrefOutputPass2(
							tag, "", "false", "");

					// If RREF, make cross reference
					// a row in a table
					if( match == RREF_match )
					{	ConvertOutputString(tag, 0);
						if( PrintableOmhelp() )
						{	OutputString(": ");
							OutputString(
								C->printid);
						}
						HrefEnd("");
						OutputString("</td><td>\n");
						ConvertOutputString(
							title, 0);
						OutputString(
						"</td></tr>\n<tr><td>\n");
					}
					else
					{
						ConvertOutputString(
							title, 0);
						if( PrintableOmhelp() )
						{	OutputString(": ");
							OutputString(
								C->printid);
						}
						HrefEnd("");
					}
				}
				FreeMem(tag);
			}
			if(match == ENDHREF_match && lastCrossReferenceDefined)
			{
				if( lastCrossReference != NULL 
				&&  PrintableOmhelp() )
				{
					OutputString( ": " );
					OutputString( 
						lastCrossReference->printid 
					);
				}

				HrefEnd("");
			}
		
			// get next character
			ch = getc(fpTmp);
		}

		
		// flush output and reset state to zero
		MatchOrOutput(EOF);
		if( ! PrintableOmhelp() )
		{	OutputString("\n</body>\n</html>\n");
			PopOutput();
		}
		
		// close this input file
		fclose(fpTmp);

		// delete the temporary file
		remove(NameTmp);

		// free allocation for this section
		FreeMem(NameTmp);

		// now children
		if( RootHasChildren )
			SecondPass(F->children);
		else
		{	assert( F->children != NULL );
			assert( strcmp(F->children->tag, CONTENTS_TAG) == 0 );
			assert( F->next     == NULL );
		}
		
		// now siblings
		F = F->next;

	}
	return;
}

static void Appendices()
{	// appendices used only if root has children

	int     letterheadings;

	CheckSpell = 0;

	letterheadings = 0;
	AutomaticAppendSection(
		SectionTree,
		REFERENCE_TAG,
		"Alphabetic Listing of Cross Reference Tags", 
		letterheadings
	);
	FunRefPass1( SectionFind(SectionTree, REFERENCE_TAG) );

	AutomaticAppendSection(
		SectionTree,
		INDEX_TAG,
		"Keyword Index",
		letterheadings
	);
	IndexPass1(  SectionFind(SectionTree, INDEX_TAG)     );

	if( ! PrintableOmhelp() )
	{	// insert the search utility in the section tree
		// but close the search file later so happens even if
		// root has no children
		char *searchTitle;
		if( SiteName() != NULL )
			searchTitle = strjoin("Search ", SiteName());
		else	searchTitle = str_alloc("Search This Web Site");
		AutomaticAppendSection(
			SectionTree,
			SEARCH_TAG,
			searchTitle,
			letterheadings
		);
		FreeMem(searchTitle);

	}
	if( DebugOmhelp )
	{	AutomaticAppendSection(
			SectionTree,
			EXTERNAL_TAG,
			"External Internet References",
			letterheadings
		);
		HrefOutputList( 
			SectionFind(SectionTree, EXTERNAL_TAG) 
		);
	}

	ContentPass1( SectionFind(SectionTree, CONTENTS_TAG) );
}

static void FinishUp()
{
	char *tmp;

	// done with macros defined at the Root level
	LatexMacroFree();
	LatexMacroFree();

	// must close search file even if root has no children
	CloseSearchFile( ! RootHasChildren );

	// Separate trace information from error message during second pass
	printf("\nBegin Second Pass\n");

	if( ! PrintableOmhelp() )
	{	char *index;

		SecondPass(SectionTree);

		if( RootHasChildren )
		{
			// use index.ext to link to the starting seciton
			index = strjoin(
				"index",
				Internal2Out("OutputExtension")
			);
			tmp   = strjoin(
				SectionTree->tagLower, 
				Internal2Out("OutputExtension")
			);

			copyfile(index, tmp);

			FreeMem(tmp);
			FreeMem(index);
		}
	}
	else
	{
		char *filename;
		filename = strjoin(
			PRINTABLE_TAG, 
			Internal2Out("OutputExtension")
		);
		PushOutput(filename);
		FreeMem(filename);
		OutputString(Internal2Out("StartOutputFile"));
		OutputString("\n");

		// just title: no keywords or style for printable version
		OutputString("<head><title>");
		ConvertOutputString(SectionTree->title, 0);
		OutputString("</title></head>\n");

		OutputString("<body>\n");

		SecondPass(SectionTree);

		OutputString("\n</body>\n</html>\n");
		PopOutput();
	}
	
	FunRefFree();
	IndexFreeMem();

	SectionFreeTree(SectionTree);

	InputFree();

	FreeCrossReference();

	FreeSpelling(DebugOmhelp);

	ExecuteFree();

	HrefFreeMemory();

	copyfileFreeMemory();

}

static void SkipCodep(int line, char *s)
{	char *next;
	char *last;
	
	next = s;
	last  = s + strlen(s) - 1;

	/*
	skip to the first newline
	*/
	while( *next != '\n' && *next != '\0' )
		next++;
	if( *next != '\n' ) fatalomh(
		"A new line was expected ",
		"after the $codep command in line ",
		int2str(line),
		NULL
	);

	// find last character to include
	while( *last != '\n' )
		last--;

	// could not have gone past newline found by next pointer
	assert( next <= last );

	if( next == last ) fatalomh(
		"The output for $codep Text$$ comes after the first\n",
		"newline in Text and before the last.\n",
		"The output specified by the $codep command in line ",
		int2str(line),
		" is empty",
		NULL
	);

	
	// skift the string pointed to by s
	while( next <= last )
		*s++ = *next++;

	// new termination point
	*s = '\0';
}

/**********************************************************************/

const char *Tag2Title(const char *tag)
{	SectionInfo *F;
	F = SectionFind(SectionTree, tag);
	if( F == NULL )
		return NULL;
	else	return F->title;
}

void InitParser(const char *StartingInputFile)
{	char *s;
	char *LocalDirectory;
	char *searchTitle;
	int letterheadings;

	// initialize LocalName to avoid warning 
	// (compiler does not know fatalerr will not return)
	char *LocalName = NULL;

	// extract the directory and name rom StartingInputFile
	LocalDirectory = str_alloc(StartingInputFile);
	s              = LocalDirectory + strlen(LocalDirectory);
	while( s > LocalDirectory && *s != '/' && *s != '\\' )
		s--;
	if( *s == '/' || *s == '\\' )
	{	LocalName = str_alloc(s + 1);
		*(s+1) = '\0';
	}
	else	fatalerr(
		"The starting input file specification\n",
		"does not contain a directory name.\n",
		"If you must run OMhelp in the directory\n",
		"where the starting input file is located,\n",
		"place .\\ in front of the file name",
		NULL
	);


	InputInit(LocalDirectory);
	
	assert(SectionTree == NULL);

	// starting of section tree
	SectionTree    = SectionInfoNew(NULL, LocalName);
	CurrentSection = SectionTree;

	// Table of Contents is first child of starting section
	letterheadings = 0;
	AutomaticAppendSection(
		SectionTree,
		CONTENTS_TAG,
		"Table of Contents",
		letterheadings
	);
	assert( SectionTree->children != NULL );
	assert( strcmp(SectionTree->children->tag, CONTENTS_TAG) == 0 );

	PushOmhInput(CurrentSection);

	if( SiteName() != NULL )
		searchTitle = strjoin("Search ", SiteName());
	else	searchTitle = str_alloc("Search This Web Site");
	OpenSearchFile(SEARCH_TAG, searchTitle);
	FreeMem(searchTitle);

	FreeMem(LocalDirectory);
	FreeMem(LocalName);
}



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 1309 "omhelp.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   2363

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  76
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  89
/* YYNRULES -- Number of rules.  */
#define YYNRULES  271
/* YYNRULES -- Number of states.  */
#define YYNSTATES  405

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   330

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     7,     8,    10,    12,    14,    16,    18,
      20,    22,    24,    26,    28,    30,    32,    34,    36,    38,
      40,    42,    44,    46,    48,    50,    52,    54,    56,    58,
      60,    62,    64,    66,    68,    70,    72,    74,    76,    78,
      80,    82,    84,    86,    88,    90,    92,    94,    96,    98,
     100,   102,   104,   106,   108,   110,   112,   114,   116,   118,
     120,   122,   124,   126,   128,   130,   132,   134,   136,   138,
     140,   143,   145,   149,   153,   157,   161,   163,   167,   171,
     175,   179,   181,   185,   187,   191,   193,   195,   197,   199,
     203,   205,   207,   209,   213,   215,   217,   219,   221,   223,
     227,   231,   233,   237,   241,   245,   249,   253,   257,   261,
     265,   269,   271,   275,   279,   281,   283,   287,   291,   295,
     299,   303,   307,   311,   315,   317,   321,   325,   329,   333,
     337,   339,   341,   345,   349,   353,   357,   359,   363,   365,
     367,   369,   371,   373,   375,   377,   379,   381,   383,   385,
     387,   389,   391,   393,   395,   397,   399,   401,   403,   405,
     407,   409,   411,   413,   415,   417,   419,   421,   423,   425,
     427,   429,   431,   433,   435,   437,   439,   441,   443,   445,
     447,   449,   451,   453,   455,   457,   459,   461,   463,   465,
     467,   469,   471,   473,   475,   477,   479,   481,   483,   485,
     487,   489,   491,   493,   495,   499,   503,   505,   509,   513,
     515,   519,   523,   527,   531,   535,   539,   543,   547,   551,
     555,   557,   561,   563,   565,   567,   569,   573,   576,   580,
     584,   588,   590,   592,   594,   598,   602,   606,   610,   614,
     618,   622,   626,   628,   632,   636,   640,   644,   648,   652,
     656,   658,   662,   666,   668,   670,   672,   676,   680,   684,
     688,   692,   696,   700,   704,   708,   712,   716,   720,   724,
     728,   732
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
      77,     0,    -1,    78,    80,    25,    -1,    -1,    81,    -1,
      82,    -1,    83,    -1,    85,    -1,    86,    -1,    88,    -1,
      90,    -1,    94,    -1,    97,    -1,   100,    -1,    91,    -1,
     102,    -1,   103,    -1,   104,    -1,   105,    -1,   106,    -1,
     107,    -1,   108,    -1,   109,    -1,   110,    -1,   111,    -1,
     112,    -1,   113,    -1,   114,    -1,   116,    -1,   117,    -1,
     118,    -1,   120,    -1,   121,    -1,   122,    -1,   124,    -1,
     126,    -1,   127,    -1,   128,    -1,   129,    -1,   130,    -1,
     131,    -1,   134,    -1,   136,    -1,   138,    -1,   139,    -1,
     140,    -1,   132,    -1,   133,    -1,   143,    -1,   141,    -1,
     145,    -1,   146,    -1,   148,    -1,   149,    -1,   150,    -1,
     151,    -1,   152,    -1,   153,    -1,   154,    -1,   155,    -1,
     157,    -1,   158,    -1,   159,    -1,   144,    -1,   160,    -1,
     161,    -1,   162,    -1,   163,    -1,   164,    -1,    79,    -1,
      80,    79,    -1,     3,    -1,     4,   155,   137,    -1,     4,
      84,    25,    -1,     5,   155,   137,    -1,     5,    84,    25,
      -1,   155,    -1,     6,   155,   137,    -1,     6,    84,    25,
      -1,     7,   155,   137,    -1,     7,   155,    25,    -1,     8,
      -1,    87,    80,    25,    -1,     9,    -1,    89,    80,    25,
      -1,    92,    -1,    10,    -1,    16,    -1,    11,    -1,    93,
      80,    25,    -1,    21,    -1,    13,    -1,    95,    -1,    98,
     155,    25,    -1,    12,    -1,    96,    -1,    14,    -1,    45,
      -1,    38,    -1,    15,   155,   137,    -1,    15,    84,    25,
      -1,    17,    -1,   101,    80,    25,    -1,    18,   155,   137,
      -1,    18,   155,    25,    -1,    19,   155,   137,    -1,    19,
     155,    25,    -1,    20,   155,   137,    -1,    20,    67,    25,
      -1,    22,   155,   137,    -1,    22,   155,    25,    -1,    23,
      -1,    24,   155,   137,    -1,    24,    84,    25,    -1,    26,
      -1,    27,    -1,    28,   155,   137,    -1,    28,   155,    25,
      -1,    29,   155,   137,    -1,    29,    84,    25,    -1,    30,
     155,   137,    -1,    30,    84,    25,    -1,    31,   155,   137,
      -1,    31,    84,    25,    -1,    32,    -1,   115,    80,    25,
      -1,    33,   155,   137,    -1,    33,    84,    25,    -1,    34,
     155,   137,    -1,    34,   155,    25,    -1,    35,    -1,    36,
      -1,   119,    84,    25,    -1,    37,   155,   137,    -1,    37,
      84,    25,    -1,    99,   155,    25,    -1,    39,    -1,   123,
      80,    25,    -1,     4,    -1,     5,    -1,     6,    -1,     7,
      -1,     8,    -1,     9,    -1,    10,    -1,    11,    -1,    12,
      -1,    13,    -1,    14,    -1,    15,    -1,    16,    -1,    17,
      -1,    18,    -1,    19,    -1,    20,    -1,    21,    -1,    23,
      -1,    24,    -1,    26,    -1,    28,    -1,    29,    -1,    30,
      -1,    31,    -1,    32,    -1,    33,    -1,    34,    -1,    35,
      -1,    36,    -1,    37,    -1,    38,    -1,    39,    -1,    40,
      -1,    41,    -1,    42,    -1,    43,    -1,    44,    -1,    45,
      -1,    46,    -1,    48,    -1,    49,    -1,    50,    -1,    52,
      -1,    53,    -1,    54,    -1,    55,    -1,    56,    -1,    57,
      -1,    58,    -1,    59,    -1,    60,    -1,    61,    -1,    62,
      -1,    63,    -1,    64,    -1,    65,    -1,    66,    -1,    68,
      -1,    69,    -1,    70,    -1,    71,    -1,    72,    -1,    73,
      -1,    74,    -1,    75,    -1,    40,   155,   137,    -1,    40,
     155,    25,    -1,    41,    -1,    42,   155,   137,    -1,    42,
      84,    25,    -1,    43,    -1,    44,   155,   137,    -1,    44,
     155,    25,    -1,    46,   155,   137,    -1,    46,   155,    25,
      -1,    47,   155,   137,    -1,    47,   155,    25,    -1,    48,
     155,   137,    -1,    48,    84,    25,    -1,    49,   155,   137,
      -1,    49,   155,    25,    -1,    50,    -1,   135,    80,    25,
      -1,   125,    -1,     3,    -1,    27,    -1,    51,    -1,    51,
     155,   137,    -1,    51,    25,    -1,    52,   155,    25,    -1,
      53,   155,   137,    -1,    53,   155,    25,    -1,   142,    -1,
      54,    -1,    56,    -1,    55,   155,   137,    -1,    55,    84,
      25,    -1,    57,   155,   137,    -1,    57,    84,    25,    -1,
      58,   155,   137,    -1,    58,    84,    25,    -1,    59,   155,
     137,    -1,    59,    84,    25,    -1,    60,    -1,   147,    80,
      25,    -1,    61,   155,   137,    -1,    61,   155,    25,    -1,
      62,   155,   137,    -1,    62,    84,    25,    -1,    63,   155,
     137,    -1,    63,   155,    25,    -1,    64,    -1,    65,   155,
     137,    -1,    65,    84,    25,    -1,    66,    -1,   156,    -1,
      67,    -1,    68,   155,   137,    -1,    68,   155,    25,    -1,
      69,   155,   137,    -1,    69,    84,    25,    -1,    71,   155,
     137,    -1,    71,   155,    25,    -1,    70,   155,   137,    -1,
      70,    84,    25,    -1,    72,   155,   137,    -1,    72,    84,
      25,    -1,    73,   155,   137,    -1,    73,   155,    25,    -1,
      74,   155,   137,    -1,    74,    84,    25,    -1,    75,   155,
     137,    -1,    75,   155,    25,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,  1140,  1140,  1151,  1156,  1157,  1158,  1159,  1160,  1161,
    1162,  1163,  1164,  1165,  1166,  1167,  1168,  1169,  1170,  1171,
    1172,  1173,  1174,  1175,  1176,  1177,  1178,  1179,  1180,  1181,
    1182,  1183,  1184,  1185,  1186,  1187,  1188,  1189,  1190,  1191,
    1192,  1193,  1194,  1195,  1196,  1197,  1198,  1199,  1200,  1201,
    1202,  1203,  1204,  1205,  1206,  1207,  1208,  1209,  1210,  1211,
    1238,  1239,  1240,  1241,  1242,  1243,  1244,  1245,  1246,  1250,
    1254,  1261,  1336,  1339,  1365,  1368,  1401,  1409,  1412,  1592,
    1595,  1621,  1632,  1645,  1656,  1669,  1693,  1697,  1704,  1719,
    1734,  1740,  1749,  1818,  1927,  1935,  1944,  1950,  1956,  1965,
    1968,  1982,  1995,  2008,  2011,  2026,  2029,  2076,  2079,  2091,
    2094,  2226,  2263,  2266,  2280,  2375,  2500,  2503,  2517,  2520,
    2535,  2538,  2581,  2584,  2655,  2666,  2679,  2682,  2797,  2800,
    2909,  2916,  2926,  3050,  3053,  3104,  3203,  3215,  3230,  3231,
    3232,  3233,  3234,  3235,  3236,  3237,  3238,  3239,  3240,  3241,
    3242,  3243,  3244,  3245,  3246,  3247,  3248,  3249,  3250,  3251,
    3252,  3253,  3254,  3255,  3256,  3257,  3258,  3259,  3260,  3261,
    3262,  3263,  3264,  3265,  3266,  3267,  3268,  3269,  3270,  3271,
    3272,  3273,  3274,  3275,  3276,  3277,  3278,  3279,  3280,  3281,
    3282,  3283,  3284,  3285,  3286,  3287,  3288,  3289,  3290,  3291,
    3292,  3293,  3294,  3295,  3301,  3304,  3365,  3386,  3389,  3458,
    3477,  3480,  3520,  3523,  3597,  3600,  3616,  3619,  3641,  3644,
    3662,  3673,  3686,  3687,  3688,  3689,  3693,  3696,  3715,  3754,
    3757,  3795,  3826,  3833,  3843,  3846,  3860,  3863,  3903,  3906,
    3996,  3999,  4011,  4022,  4036,  4039,  4055,  4058,  4181,  4184,
    4251,  4274,  4277,  4310,  4335,  4343,  4403,  4406,  4432,  4435,
    4460,  4463,  4476,  4479,  4508,  4511,  4554,  4557,  4762,  4765,
    4780,  4783
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "ACCENT_lex", "AINDEX_lex", "ALIGN_lex",
  "BEGIN_lex", "BGCOLOR_lex", "BIG_lex", "BOLD_lex", "CEND_lex",
  "CENTER_lex", "CHILDREN_lex", "CHILDTABLE_lex", "CINDEX_lex",
  "CMARK_lex", "CNEXT_lex", "CODE_lex", "CODECOLOR_lex", "CODEP_lex",
  "COMMENT_lex", "CONTENTS_lex", "CREF_lex", "DATE_lex", "DOLLAR_lex",
  "DOUBLE_DOLLAR_lex", "END_lex", "EOF_lex", "ERRORCOLOR_lex",
  "ESCAPE_lex", "EXECUTE_lex", "FEND_lex", "FIXED_lex", "HEAD_lex",
  "HREF_lex", "ICON_lex", "IMAGE_lex", "INCLUDE_lex", "INDEX_lex",
  "ITALIC_lex", "LATEX_lex", "LEND_lex", "LIST_lex", "LNEXT_lex",
  "MATH_lex", "MINDEX_lex", "MREF_lex", "NAVIGATE_lex", "NEWLINECH_lex",
  "NOBREAK_lex", "NOSPELL_lex", "NUMBER_lex", "PATH_lex", "PRE_lex",
  "REND_lex", "RMARK_lex", "RNEXT_lex", "RREF_lex", "SECTION_lex",
  "SKIPNL_lex", "SMALL_lex", "SPELL_lex", "SUBHEAD_lex", "SYNTAX_lex",
  "TABLE_lex", "TABSIZE_lex", "TEND_lex", "TEXT_lex", "TEXTCOLOR_lex",
  "TH_lex", "TITLE_lex", "TRACE_lex", "TREF_lex", "VERBATIM_lex",
  "WSPACE_lex", "XREF_lex", "$accept", "start", "init", "element",
  "element_list", "accent", "aindex", "align", "argument", "begin",
  "bgcolor", "big_begin", "big", "bold_begin", "bold", "cnext",
  "cnext_cases", "center_begin", "center", "contents", "childhead",
  "childlist", "children", "cmindex", "cmark", "code_begin", "code",
  "codecolor", "codep", "comment", "cref", "date", "dollar", "end", "eof",
  "errorcolor", "escape", "execute", "fend", "fixed_begin", "fixed",
  "head", "href", "image_begin", "image", "include", "index",
  "italic_begin", "italic", "keyword", "latex", "lend", "list", "lnext",
  "math", "mref", "navigate", "newlinech", "nobreak", "nospell_begin",
  "nospell", "not_2_dollar_or_text", "number", "path", "pre", "rnext",
  "rnext_cases", "rmark", "rref", "section", "skipnl", "small_begin",
  "small", "spell", "subhead", "syntax", "table", "tabsize", "tend",
  "text", "text_raw", "textcolor", "th", "trace", "title", "tref",
  "verbatim", "wspace", "xref", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    76,    77,    78,    79,    79,    79,    79,    79,    79,
      79,    79,    79,    79,    79,    79,    79,    79,    79,    79,
      79,    79,    79,    79,    79,    79,    79,    79,    79,    79,
      79,    79,    79,    79,    79,    79,    79,    79,    79,    79,
      79,    79,    79,    79,    79,    79,    79,    79,    79,    79,
      79,    79,    79,    79,    79,    79,    79,    79,    79,    79,
      79,    79,    79,    79,    79,    79,    79,    79,    79,    80,
      80,    81,    82,    82,    83,    83,    84,    85,    85,    86,
      86,    87,    88,    89,    90,    91,    92,    92,    93,    94,
      95,    95,    96,    97,    98,    98,    99,    99,    99,   100,
     100,   101,   102,   103,   103,   104,   104,   105,   105,   106,
     106,   107,   108,   108,   109,   110,   111,   111,   112,   112,
     113,   113,   114,   114,   115,   116,   117,   117,   118,   118,
     119,   119,   120,   121,   121,   122,   123,   124,   125,   125,
     125,   125,   125,   125,   125,   125,   125,   125,   125,   125,
     125,   125,   125,   125,   125,   125,   125,   125,   125,   125,
     125,   125,   125,   125,   125,   125,   125,   125,   125,   125,
     125,   125,   125,   125,   125,   125,   125,   125,   125,   125,
     125,   125,   125,   125,   125,   125,   125,   125,   125,   125,
     125,   125,   125,   125,   125,   125,   125,   125,   125,   125,
     125,   125,   125,   125,   126,   126,   127,   128,   128,   129,
     130,   130,   131,   131,   132,   132,   133,   133,   134,   134,
     135,   136,   137,   137,   137,   137,   138,   138,   139,   140,
     140,   141,   142,   142,   143,   143,   144,   144,   145,   145,
     146,   146,   147,   148,   149,   149,   150,   150,   151,   151,
     152,   153,   153,   154,   155,   156,   157,   157,   158,   158,
     159,   159,   160,   160,   161,   161,   162,   162,   163,   163,
     164,   164
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     3,     0,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       2,     1,     3,     3,     3,     3,     1,     3,     3,     3,
       3,     1,     3,     1,     3,     1,     1,     1,     1,     3,
       1,     1,     1,     3,     1,     1,     1,     1,     1,     3,
       3,     1,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     1,     3,     3,     1,     1,     3,     3,     3,     3,
       3,     3,     3,     3,     1,     3,     3,     3,     3,     3,
       1,     1,     3,     3,     3,     3,     1,     3,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     3,     3,     1,     3,     3,     1,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       1,     3,     1,     1,     1,     1,     3,     2,     3,     3,
       3,     1,     1,     1,     3,     3,     3,     3,     3,     3,
       3,     3,     1,     3,     3,     3,     3,     3,     3,     3,
       1,     3,     3,     1,     1,     1,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       3,     0,     0,     1,    71,     0,     0,     0,     0,    81,
      83,    86,    88,    94,    91,    96,     0,    87,   101,     0,
       0,     0,    90,     0,   111,     0,   114,   115,     0,     0,
       0,     0,   124,     0,     0,   130,   131,     0,    98,   136,
       0,   206,     0,   209,     0,    97,     0,     0,     0,     0,
     220,     0,     0,     0,   232,     0,   233,     0,     0,     0,
     242,     0,     0,     0,   250,     0,   253,   255,     0,     0,
       0,     0,     0,     0,     0,     0,    69,     0,     4,     5,
       6,     7,     8,     0,     9,     0,    10,    14,    85,     0,
      11,    92,    95,    12,     0,     0,    13,     0,    15,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,     0,    28,    29,    30,     0,    31,    32,    33,     0,
      34,    35,    36,    37,    38,    39,    40,    46,    47,    41,
       0,    42,    43,    44,    45,    49,   231,    48,    63,    50,
      51,     0,    52,    53,    54,    55,    56,    57,    58,    59,
     254,    60,    61,    62,    64,    65,    66,    67,    68,     0,
      76,     0,    76,     0,    76,     0,     0,    76,     0,     0,
     255,     0,     0,     0,    76,     0,     0,    76,     0,    76,
       0,    76,     0,    76,     0,     0,    76,     0,     0,    76,
       0,     0,     0,     0,    76,     0,   227,     0,     0,     0,
       0,    76,     0,    76,     0,    76,     0,    76,     0,     0,
      76,     0,     0,    76,     0,     0,    76,     0,    76,     0,
       0,    76,     0,     0,    76,     0,     2,    70,     0,     0,
       0,     0,     0,     0,     0,     0,    76,     0,     0,     0,
      73,   223,   138,   139,   140,   141,   142,   143,   144,   145,
     146,   147,   148,   149,   150,   151,   152,   153,   154,   155,
     156,   157,   158,   224,   159,   160,   161,   162,   163,   164,
     165,   166,   167,   168,   169,   170,   171,   172,   173,   174,
     175,   176,   177,   178,   179,   180,   225,   181,   182,   183,
     184,   185,   186,   187,   188,   189,   190,   191,   192,   193,
     194,   195,   196,   197,   198,   199,   200,   201,   202,   203,
     222,    72,    75,    74,    78,    77,    80,    79,   100,    99,
     104,   103,   106,   105,   108,   107,   110,   109,   113,   112,
     117,   116,   119,   118,   121,   120,   123,   122,   127,   126,
     129,   128,   134,   133,   205,   204,   208,   207,   211,   210,
     213,   212,   215,   214,   217,   216,   219,   218,   226,   228,
     230,   229,   235,   234,   237,   236,   239,   238,   241,   240,
     245,   244,   247,   246,   249,   248,   252,   251,   257,   256,
     259,   258,   263,   262,   261,   260,   265,   264,   267,   266,
     269,   268,   271,   270,    82,    84,    89,    93,   135,   102,
     125,   132,   137,   221,   243
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,     2,    76,    77,    78,    79,    80,   159,    81,
      82,    83,    84,    85,    86,    87,    88,    89,    90,    91,
      92,    93,    94,    95,    96,    97,    98,    99,   100,   101,
     102,   103,   104,   105,   106,   107,   108,   109,   110,   111,
     112,   113,   114,   115,   116,   117,   118,   119,   120,   310,
     121,   122,   123,   124,   125,   126,   127,   128,   129,   130,
     131,   311,   132,   133,   134,   135,   136,   137,   138,   139,
     140,   141,   142,   143,   144,   145,   146,   147,   148,   149,
     150,   151,   152,   153,   154,   155,   156,   157,   158
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -78
static const yytype_int16 yypact[] =
{
     -78,     5,   837,   -78,   -78,   -61,   -61,   -61,   -61,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -61,   -78,   -78,   -61,
     -61,   -60,   -78,   -61,   -78,   -61,   -78,   -78,   -61,   -61,
     -61,   -61,   -78,   -61,   -61,   -78,   -78,   -61,   -78,   -78,
     -61,   -78,   -61,   -78,   -61,   -78,   -61,   -61,   -61,   -61,
     -78,   -17,   -61,   -61,   -78,   -61,   -78,   -61,   -61,   -61,
     -78,   -61,   -61,   -61,   -78,   -61,   -78,   -78,   -61,   -61,
     -61,   -61,   -61,   -61,   -61,   -61,   -78,   180,   -78,   -78,
     -78,   -78,   -78,   837,   -78,   837,   -78,   -78,   -78,   837,
     -78,   -78,   -78,   -78,   -61,   -61,   -78,   837,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   837,   -78,   -78,   -78,   -61,   -78,   -78,   -78,   837,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     837,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   837,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -16,
    2224,   -15,  2224,   -14,  2224,   910,   -12,  2224,   983,  1056,
     -11,  2224,  1129,    -7,  2224,  1202,    -5,  2224,    -2,  2224,
       3,  2224,     6,  2224,  1275,     7,  2224,  1348,     9,  2224,
    1421,  1494,  1567,    10,  2224,  1640,   -78,  2224,    12,  1713,
      14,  2224,    16,  2224,    21,  2224,    27,  2224,  1786,    31,
    2224,  1859,    35,  2224,  1932,    37,  2224,    38,  2224,  2005,
      47,  2224,  2078,    50,  2224,  2151,   -78,   -78,   253,   326,
     399,    51,    52,   472,   545,    53,   -78,   618,   691,   764,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
     -78,   -78,   -78,   -77,    -3,   -78,   -78,   -78,    67,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,  2138,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,    -4,
     -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78,   -78
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -1
static const yytype_uint16 yytable[] =
{
     227,   160,   162,   164,   165,     3,    67,   170,   196,   240,
     312,   314,   167,   318,   324,   168,   169,   171,   328,   172,
     332,   174,     0,   334,   175,   177,   179,   181,   336,   183,
     184,   338,   342,   186,   346,   354,   187,   359,   189,   362,
     190,   364,   191,   192,   194,   195,   366,   197,   198,   199,
      67,   201,   368,   203,   205,   207,   372,   208,   210,   211,
     376,   213,   380,   382,   214,   216,   218,   219,   221,   222,
     224,   225,   386,   161,   163,   390,   397,   398,   401,     0,
     228,     0,   229,   166,     0,     0,   230,     0,     0,     0,
     231,   232,   173,     0,   233,     0,   176,   178,   180,     0,
     182,     0,     0,     0,   185,     0,     0,     0,   234,   188,
       0,   236,     0,     0,     0,   193,   237,     0,     0,     0,
       0,     0,   200,     0,   202,   204,   206,   238,     0,   209,
       0,     0,   212,     0,     0,     0,   215,   217,   239,   220,
       0,   223,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   227,   227,   227,     0,     0,   227,   227,     0,     0,
     227,   227,   227,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   235,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,   226,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,     4,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,   394,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,   395,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,   396,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,   399,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
     400,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,     4,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,   402,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,   403,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,   404,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,     0,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,   241,   242,   243,   244,   245,   246,   247,
     248,   249,   250,   251,   252,   253,   254,   255,   256,   257,
     258,   259,     0,   260,   261,   316,   262,   263,   264,   265,
     266,   267,   268,   269,   270,   271,   272,   273,   274,   275,
     276,   277,   278,   279,   280,   281,   282,     0,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,     0,   302,   303,
     304,   305,   306,   307,   308,   309,   241,   242,   243,   244,
     245,   246,   247,   248,   249,   250,   251,   252,   253,   254,
     255,   256,   257,   258,   259,     0,   260,   261,   320,   262,
     263,   264,   265,   266,   267,   268,   269,   270,   271,   272,
     273,   274,   275,   276,   277,   278,   279,   280,   281,   282,
       0,   283,   284,   285,   286,   287,   288,   289,   290,   291,
     292,   293,   294,   295,   296,   297,   298,   299,   300,   301,
       0,   302,   303,   304,   305,   306,   307,   308,   309,   241,
     242,   243,   244,   245,   246,   247,   248,   249,   250,   251,
     252,   253,   254,   255,   256,   257,   258,   259,     0,   260,
     261,   322,   262,   263,   264,   265,   266,   267,   268,   269,
     270,   271,   272,   273,   274,   275,   276,   277,   278,   279,
     280,   281,   282,     0,   283,   284,   285,   286,   287,   288,
     289,   290,   291,   292,   293,   294,   295,   296,   297,   298,
     299,   300,   301,     0,   302,   303,   304,   305,   306,   307,
     308,   309,   241,   242,   243,   244,   245,   246,   247,   248,
     249,   250,   251,   252,   253,   254,   255,   256,   257,   258,
     259,     0,   260,   261,   326,   262,   263,   264,   265,   266,
     267,   268,   269,   270,   271,   272,   273,   274,   275,   276,
     277,   278,   279,   280,   281,   282,     0,   283,   284,   285,
     286,   287,   288,   289,   290,   291,   292,   293,   294,   295,
     296,   297,   298,   299,   300,   301,     0,   302,   303,   304,
     305,   306,   307,   308,   309,   241,   242,   243,   244,   245,
     246,   247,   248,   249,   250,   251,   252,   253,   254,   255,
     256,   257,   258,   259,     0,   260,   261,   330,   262,   263,
     264,   265,   266,   267,   268,   269,   270,   271,   272,   273,
     274,   275,   276,   277,   278,   279,   280,   281,   282,     0,
     283,   284,   285,   286,   287,   288,   289,   290,   291,   292,
     293,   294,   295,   296,   297,   298,   299,   300,   301,     0,
     302,   303,   304,   305,   306,   307,   308,   309,   241,   242,
     243,   244,   245,   246,   247,   248,   249,   250,   251,   252,
     253,   254,   255,   256,   257,   258,   259,     0,   260,   261,
     340,   262,   263,   264,   265,   266,   267,   268,   269,   270,
     271,   272,   273,   274,   275,   276,   277,   278,   279,   280,
     281,   282,     0,   283,   284,   285,   286,   287,   288,   289,
     290,   291,   292,   293,   294,   295,   296,   297,   298,   299,
     300,   301,     0,   302,   303,   304,   305,   306,   307,   308,
     309,   241,   242,   243,   244,   245,   246,   247,   248,   249,
     250,   251,   252,   253,   254,   255,   256,   257,   258,   259,
       0,   260,   261,   344,   262,   263,   264,   265,   266,   267,
     268,   269,   270,   271,   272,   273,   274,   275,   276,   277,
     278,   279,   280,   281,   282,     0,   283,   284,   285,   286,
     287,   288,   289,   290,   291,   292,   293,   294,   295,   296,
     297,   298,   299,   300,   301,     0,   302,   303,   304,   305,
     306,   307,   308,   309,   241,   242,   243,   244,   245,   246,
     247,   248,   249,   250,   251,   252,   253,   254,   255,   256,
     257,   258,   259,     0,   260,   261,   348,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,     0,   283,
     284,   285,   286,   287,   288,   289,   290,   291,   292,   293,
     294,   295,   296,   297,   298,   299,   300,   301,     0,   302,
     303,   304,   305,   306,   307,   308,   309,   241,   242,   243,
     244,   245,   246,   247,   248,   249,   250,   251,   252,   253,
     254,   255,   256,   257,   258,   259,     0,   260,   261,   350,
     262,   263,   264,   265,   266,   267,   268,   269,   270,   271,
     272,   273,   274,   275,   276,   277,   278,   279,   280,   281,
     282,     0,   283,   284,   285,   286,   287,   288,   289,   290,
     291,   292,   293,   294,   295,   296,   297,   298,   299,   300,
     301,     0,   302,   303,   304,   305,   306,   307,   308,   309,
     241,   242,   243,   244,   245,   246,   247,   248,   249,   250,
     251,   252,   253,   254,   255,   256,   257,   258,   259,     0,
     260,   261,   352,   262,   263,   264,   265,   266,   267,   268,
     269,   270,   271,   272,   273,   274,   275,   276,   277,   278,
     279,   280,   281,   282,     0,   283,   284,   285,   286,   287,
     288,   289,   290,   291,   292,   293,   294,   295,   296,   297,
     298,   299,   300,   301,     0,   302,   303,   304,   305,   306,
     307,   308,   309,   241,   242,   243,   244,   245,   246,   247,
     248,   249,   250,   251,   252,   253,   254,   255,   256,   257,
     258,   259,     0,   260,   261,   356,   262,   263,   264,   265,
     266,   267,   268,   269,   270,   271,   272,   273,   274,   275,
     276,   277,   278,   279,   280,   281,   282,     0,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,     0,   302,   303,
     304,   305,   306,   307,   308,   309,   241,   242,   243,   244,
     245,   246,   247,   248,   249,   250,   251,   252,   253,   254,
     255,   256,   257,   258,   259,     0,   260,   261,   360,   262,
     263,   264,   265,   266,   267,   268,   269,   270,   271,   272,
     273,   274,   275,   276,   277,   278,   279,   280,   281,   282,
       0,   283,   284,   285,   286,   287,   288,   289,   290,   291,
     292,   293,   294,   295,   296,   297,   298,   299,   300,   301,
       0,   302,   303,   304,   305,   306,   307,   308,   309,   241,
     242,   243,   244,   245,   246,   247,   248,   249,   250,   251,
     252,   253,   254,   255,   256,   257,   258,   259,     0,   260,
     261,   370,   262,   263,   264,   265,   266,   267,   268,   269,
     270,   271,   272,   273,   274,   275,   276,   277,   278,   279,
     280,   281,   282,     0,   283,   284,   285,   286,   287,   288,
     289,   290,   291,   292,   293,   294,   295,   296,   297,   298,
     299,   300,   301,     0,   302,   303,   304,   305,   306,   307,
     308,   309,   241,   242,   243,   244,   245,   246,   247,   248,
     249,   250,   251,   252,   253,   254,   255,   256,   257,   258,
     259,     0,   260,   261,   374,   262,   263,   264,   265,   266,
     267,   268,   269,   270,   271,   272,   273,   274,   275,   276,
     277,   278,   279,   280,   281,   282,     0,   283,   284,   285,
     286,   287,   288,   289,   290,   291,   292,   293,   294,   295,
     296,   297,   298,   299,   300,   301,     0,   302,   303,   304,
     305,   306,   307,   308,   309,   241,   242,   243,   244,   245,
     246,   247,   248,   249,   250,   251,   252,   253,   254,   255,
     256,   257,   258,   259,     0,   260,   261,   378,   262,   263,
     264,   265,   266,   267,   268,   269,   270,   271,   272,   273,
     274,   275,   276,   277,   278,   279,   280,   281,   282,     0,
     283,   284,   285,   286,   287,   288,   289,   290,   291,   292,
     293,   294,   295,   296,   297,   298,   299,   300,   301,     0,
     302,   303,   304,   305,   306,   307,   308,   309,   241,   242,
     243,   244,   245,   246,   247,   248,   249,   250,   251,   252,
     253,   254,   255,   256,   257,   258,   259,     0,   260,   261,
     384,   262,   263,   264,   265,   266,   267,   268,   269,   270,
     271,   272,   273,   274,   275,   276,   277,   278,   279,   280,
     281,   282,     0,   283,   284,   285,   286,   287,   288,   289,
     290,   291,   292,   293,   294,   295,   296,   297,   298,   299,
     300,   301,     0,   302,   303,   304,   305,   306,   307,   308,
     309,   241,   242,   243,   244,   245,   246,   247,   248,   249,
     250,   251,   252,   253,   254,   255,   256,   257,   258,   259,
       0,   260,   261,   388,   262,   263,   264,   265,   266,   267,
     268,   269,   270,   271,   272,   273,   274,   275,   276,   277,
     278,   279,   280,   281,   282,     0,   283,   284,   285,   286,
     287,   288,   289,   290,   291,   292,   293,   294,   295,   296,
     297,   298,   299,   300,   301,     0,   302,   303,   304,   305,
     306,   307,   308,   309,   241,   242,   243,   244,   245,   246,
     247,   248,   249,   250,   251,   252,   253,   254,   255,   256,
     257,   258,   259,     0,   260,   261,   392,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,     0,   283,
     284,   285,   286,   287,   288,   289,   290,   291,   292,   293,
     294,   295,   296,   297,   298,   299,   300,   301,     0,   302,
     303,   304,   305,   306,   307,   308,   309,   241,   242,   243,
     244,   245,   246,   247,   248,   249,   250,   251,   252,   253,
     254,   255,   256,   257,   258,   259,     0,   260,   261,     0,
     262,   263,   264,   265,   266,   267,   268,   269,   270,   271,
     272,   273,   274,   275,   276,   277,   278,   279,   280,   281,
     282,     0,   283,   284,   285,   286,   287,   288,   289,   290,
     291,   292,   293,   294,   295,   296,   297,   298,   299,   300,
     301,     0,   302,   303,   304,   305,   306,   307,   308,   309,
     313,     0,   315,   317,     0,   319,   321,   323,     0,   325,
     327,     0,   329,   331,     0,   333,     0,   335,     0,   337,
       0,   339,   341,     0,   343,   345,     0,   347,   349,   351,
     353,     0,   355,   357,     0,   358,     0,   361,     0,   363,
       0,   365,     0,   367,     0,   369,   371,     0,   373,   375,
       0,   377,   379,     0,   381,     0,   383,   385,     0,   387,
     389,     0,   391,   393
};

static const yytype_int16 yycheck[] =
{
      77,     5,     6,     7,     8,     0,    67,    67,    25,    25,
      25,    25,    16,    25,    25,    19,    20,    21,    25,    23,
      25,    25,    -1,    25,    28,    29,    30,    31,    25,    33,
      34,    25,    25,    37,    25,    25,    40,    25,    42,    25,
      44,    25,    46,    47,    48,    49,    25,    51,    52,    53,
      67,    55,    25,    57,    58,    59,    25,    61,    62,    63,
      25,    65,    25,    25,    68,    69,    70,    71,    72,    73,
      74,    75,    25,     6,     7,    25,    25,    25,    25,    -1,
      83,    -1,    85,    16,    -1,    -1,    89,    -1,    -1,    -1,
      94,    95,    25,    -1,    97,    -1,    29,    30,    31,    -1,
      33,    -1,    -1,    -1,    37,    -1,    -1,    -1,   111,    42,
      -1,   115,    -1,    -1,    -1,    48,   119,    -1,    -1,    -1,
      -1,    -1,    55,    -1,    57,    58,    59,   130,    -1,    62,
      -1,    -1,    65,    -1,    -1,    -1,    69,    70,   141,    72,
      -1,    74,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   228,   229,   230,    -1,    -1,   233,   234,    -1,    -1,
     237,   238,   239,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   115,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,     3,     4,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
       3,     4,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    -1,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    -1,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    -1,    68,    69,
      70,    71,    72,    73,    74,    75,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    -1,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      -1,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      -1,    68,    69,    70,    71,    72,    73,    74,    75,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    -1,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    -1,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    -1,    68,    69,    70,    71,    72,    73,
      74,    75,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    -1,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    -1,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    -1,    68,    69,    70,
      71,    72,    73,    74,    75,     3,     4,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    -1,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    -1,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    -1,
      68,    69,    70,    71,    72,    73,    74,    75,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    -1,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    -1,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    -1,    68,    69,    70,    71,    72,    73,    74,
      75,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      -1,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    -1,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    -1,    68,    69,    70,    71,
      72,    73,    74,    75,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    -1,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    -1,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    -1,    68,
      69,    70,    71,    72,    73,    74,    75,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    -1,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    -1,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    -1,    68,    69,    70,    71,    72,    73,    74,    75,
       3,     4,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    -1,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    -1,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    -1,    68,    69,    70,    71,    72,
      73,    74,    75,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    -1,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    -1,    68,    69,
      70,    71,    72,    73,    74,    75,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    -1,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      -1,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      -1,    68,    69,    70,    71,    72,    73,    74,    75,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,    21,    -1,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    -1,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    -1,    68,    69,    70,    71,    72,    73,
      74,    75,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    -1,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    -1,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    -1,    68,    69,    70,
      71,    72,    73,    74,    75,     3,     4,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    -1,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    -1,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    -1,
      68,    69,    70,    71,    72,    73,    74,    75,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    -1,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    -1,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    -1,    68,    69,    70,    71,    72,    73,    74,
      75,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      -1,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    -1,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    -1,    68,    69,    70,    71,
      72,    73,    74,    75,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    -1,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    -1,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    -1,    68,
      69,    70,    71,    72,    73,    74,    75,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    -1,    23,    24,    -1,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    -1,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    -1,    68,    69,    70,    71,    72,    73,    74,    75,
     162,    -1,   164,   165,    -1,   167,   168,   169,    -1,   171,
     172,    -1,   174,   175,    -1,   177,    -1,   179,    -1,   181,
      -1,   183,   184,    -1,   186,   187,    -1,   189,   190,   191,
     192,    -1,   194,   195,    -1,   197,    -1,   199,    -1,   201,
      -1,   203,    -1,   205,    -1,   207,   208,    -1,   210,   211,
      -1,   213,   214,    -1,   216,    -1,   218,   219,    -1,   221,
     222,    -1,   224,   225
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    77,    78,     0,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    79,    80,    81,    82,
      83,    85,    86,    87,    88,    89,    90,    91,    92,    93,
      94,    95,    96,    97,    98,    99,   100,   101,   102,   103,
     104,   105,   106,   107,   108,   109,   110,   111,   112,   113,
     114,   115,   116,   117,   118,   119,   120,   121,   122,   123,
     124,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   138,   139,   140,   141,   142,   143,   144,   145,
     146,   147,   148,   149,   150,   151,   152,   153,   154,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,    84,
     155,    84,   155,    84,   155,   155,    84,   155,   155,   155,
      67,   155,   155,    84,   155,   155,    84,   155,    84,   155,
      84,   155,    84,   155,   155,    84,   155,   155,    84,   155,
     155,   155,   155,    84,   155,   155,    25,   155,   155,   155,
      84,   155,    84,   155,    84,   155,    84,   155,   155,    84,
     155,   155,    84,   155,   155,    84,   155,    84,   155,   155,
      84,   155,   155,    84,   155,   155,    25,    79,    80,    80,
      80,   155,   155,    80,    80,    84,   155,    80,    80,    80,
      25,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      23,    24,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    68,    69,    70,    71,    72,    73,    74,    75,
     125,   137,    25,   137,    25,   137,    25,   137,    25,   137,
      25,   137,    25,   137,    25,   137,    25,   137,    25,   137,
      25,   137,    25,   137,    25,   137,    25,   137,    25,   137,
      25,   137,    25,   137,    25,   137,    25,   137,    25,   137,
      25,   137,    25,   137,    25,   137,    25,   137,   137,    25,
      25,   137,    25,   137,    25,   137,    25,   137,    25,   137,
      25,   137,    25,   137,    25,   137,    25,   137,    25,   137,
      25,   137,    25,   137,    25,   137,    25,   137,    25,   137,
      25,   137,    25,   137,    25,    25,    25,    25,    25,    25,
      25,    25,    25,    25,    25
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 1141 "omhelp.y"
    {
		fatalomh(
			"Unexpected $$",
			NULL
		);
	;}
    break;

  case 3:
#line 1151 "omhelp.y"
    {	yydebug = 0;
	;}
    break;

  case 59:
#line 1212 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str != NULL );

		if( PreviousOutputWasHeading )
		{	
			char *s = (yyvsp[(1) - (1)]).str;
			char ch = *s++;

			while( isspace(ch) )
				ch = *s++;

			if( ! ch == '\0' )
			{	// if text is not all white space, need
				// an extra new line after previous heading
				ConvertForcedNewline(1);

				PreviousOutputWasHeading = 0;
			}
			// otherwise suspend judgement on the extra new line
		}
	
		outtext((yyvsp[(1) - (1)]).line, (yyvsp[(1) - (1)]).str, 0);
		FreeMem((yyvsp[(1) - (1)]).str);

		(yyval).str  = NULL;
		(yyval).line = (yyvsp[(1) - (1)]).line;
	;}
    break;

  case 69:
#line 1251 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );
		(yyval) = (yyvsp[(1) - (1)]); 
	;}
    break;

  case 70:
#line 1255 "omhelp.y"
    {	assert( (yyvsp[(1) - (2)]).str == NULL );
		(yyval) = (yyvsp[(1) - (2)]);
	;}
    break;

  case 71:
#line 1262 "omhelp.y"
    {	char ch;

		// initlaize to avoid warning
		// (compiler does not know fatalomh does not return)
		char *code = NULL;

		assert( (yyvsp[(1) - (1)]).str != NULL );
		assert( strlen((yyvsp[(1) - (1)]).str) == 1 );

		ch = *((yyvsp[(1) - (1)]).str);
		switch(ch)
		{	case 'A':
			code = "193";
			break;

			case 'E':
			code = "201";
			break;

			case 'I':
			code = "205";
			break;

			case 'O':
			code = "211";
			break;

			case 'U':
			code = "218";
			break;

			case 'Y':
			code = "221";
			break;

			case 'a':
			code = "225";
			break;

			case 'e':
			code = "233";
			break;

			case 'i':
			code = "237";
			break;

			case 'o':
			code = "243";
			break;

			case 'u':
			code = "250";
			break;

			case 'y':
			code = "253";
			break;

			default:
			fatalomh(
			"The character following a $' command in line ",
			int2str( (yyvsp[(1) - (1)]).line ),
	 		" is not a vowel.",
			NULL
			);
		}
		FormatOutput("&#%s;", code);

		FreeMem((yyvsp[(1) - (1)]).str);
	;}
    break;

  case 72:
#line 1337 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 73:
#line 1340 "omhelp.y"
    {	char *s;
		int i;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		s = StrCat(__FILE__, __LINE__, " ", (yyvsp[(2) - (3)]).str, " ", NULL);

		for(i = 0; s[i] != '\0'; i++)
			if( isspace(s[i]) )
				s[i] = ' ';

		MindexSection = strstr(s, " section ") != NULL;
		MindexHead    = strstr(s, " head ")    != NULL;
		MindexSubhead = strstr(s, " subhead ") != NULL;

		FreeMem(s);
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 74:
#line 1366 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 75:
#line 1369 "omhelp.y"
    {	char *s;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		s = (yyvsp[(2) - (3)]).str;
		if( strcmp(s, "left") == 0 )
			HorizontalAlign = "left";
		else if( strcmp(s, "center") == 0 )
			HorizontalAlign = "center";
		else if( strcmp(s, "right") == 0 )
			HorizontalAlign = "right";
		else if( strcmp(s, "top") == 0 )
			VerticalAlign = "top";
		else if( strcmp(s, "middle") == 0 )
			VerticalAlign = "middle";
		else if( strcmp(s, "bottom") == 0 )
			VerticalAlign = "bottom";
		else fatalomh(
			"The $align command argument in line ",
			int2str((yyvsp[(2) - (3)]).line),
			" is not one of following:\n",
			"left, center, right, top, middle, bottom",
			NULL
		);

		FreeMem((yyvsp[(2) - (3)]).str);
	;}
    break;

  case 76:
#line 1402 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str != NULL );
		ClipWhiteSpace((yyvsp[(1) - (1)]).str);
		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 77:
#line 1410 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 78:
#line 1413 "omhelp.y"
    {	char *tag;
		char *tag_lower;
		char *number = NULL;
		CrossReference *C;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );
		
		if( BeginCount != EndCount ) fatalomh(
			"The $begin command on line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\noccurs before the previous $begin ",
			"was terminated by a $end",
			NULL
		);
		BeginCount++; 

		assert( PreviousOutputWasHeading == 0 );

		// check if there is already a section in this file
		// if so, start a new sibling of current section
		if( CurrentSection->tag != NULL )
		{	// note that this operation changes the value of
			// SectionNumber(CurrentSection->next) which has
			// not yet been used.
			SectionInfo *F;
			if( CurrentSection == SectionTree ) fatalomh(
				"The $begin command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				" is the second one in the starting file\n",
				"There can only be one section at the root ",
				"of the web site tree.",
				NULL
			);
			F = SectionInfoNew(SectionTree, InputName());
			
			// links for this section
			F->next           = CurrentSection->next;
			F->previous       = CurrentSection;
			F->parent         = CurrentSection->parent;

			// this section comes after the current one
			CurrentSection->next = F;

			// this section comes before the next one
			if( F->next != NULL )
				F->next->previous = F;

			// make this the current section
			CurrentSection       = F;
		}

		// set the current section tag (and lower case version)
		tag = (yyvsp[(2) - (3)]).str;
		SectionSetTag(CurrentSection, tag);
		tag_lower = CurrentSection->tagLower;
		
		/*
		check for an invalid section tag
		*/
		if( strlen(tag) > MAX_TAG ) fatalomh(
			"In the $begin command on line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nthe section tag is more than ",
			int2str(MAX_TAG),
			" characters long",
			NULL
		);
		if( strstr(tag_lower, "_frame") != NULL ) fatalomh(
			"In the $begin command on line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nthe section tag contains the substring \"_frame\"",
			NULL
		);
		if( strstr(tag_lower, "_links") != NULL ) fatalomh(
			"In the $begin command on line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nthe section tag contains the substring \"_links\"",
			NULL
		);
		if( tag_lower[0] == '_' ) fatalomh(
			"In the $begin command on line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\n\"_\" is the first character in the section tag",
			NULL
		);
		if( strcmp(tag_lower, "index") == 0 ) fatalomh(
			"In the $begin command on line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nyou cannot use \"index\" as a section tag",
			"\nbecause \"index\" automatically links ",
			"to the starting file",
			NULL
		);

		// start a new output file
		PushTmpOutput(CurrentSection->tag);

		// start new section in search cross reference list
		SearchBegin(tag);

		// ******* Section State (default values) *****************

		// frame for the current section
		iFrame   = 1;

		// Maximum frame referenced for the current section
		MaxFrame     = 0;
		MaxFrameLine = 0;
		assert( MaxFrameFile == NULL );  // set at previous end

		// Initialize Table and List levels
		assert( TableLevel == 0 );       // checked at previous end
		assert( ListLevel  == 0 );

		// erase current alignments
		HorizontalAlign = "left";
		VerticalAlign   = "top";

		// erase the current Dollar command
		Dollar = '\0';

		// erase the current Rmark command
		Rmark = '\0';

		// erase the current copyright character
		Cmark = '\0';

		// erase the current white space character
		Wspace = '\0';

		// erase the current program comment character
		NewlineCh = '\0';
		
		// reset the current escape character
		Escape = '\\';

		// reset the automatic mindex command connections
		MindexSection = 0;
		MindexHead    = 0;
		MindexSubhead = 0;

		// reset the current color settings
		assert( ErrorColor   == NULL );    // set at previous end
		assert( CodeColor    == NULL );
		CodeColor  = str_alloc("blue");
		ErrorColor = str_alloc("red");

		// initial state of spell checker
		assert( CheckSpell == 1);


		// reset the current number of characters between tab columns
		ConvertSetTabSize(TAB_SIZE);
			
		// erase the current heading setting
		InitializeHeading();

		// erase the current special spelling list
		SpellingOkList("");

		// ********************************************************
		
		// define cross reference point
		number = SectionNumber(CurrentSection);
		C      = DefineCrossReference(tag, "", InputName(), 0, number);
		FreeMem(number);

		assert( C != NULL );

		printf(" %s:", tag);
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 79:
#line 1593 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 80:
#line 1596 "omhelp.y"
    {
		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		// only one $bgcolor per section
		if( CurrentSection->style.bgcolor != NULL ) fatalomh(
			"At $bgcolor comamnd in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nThere is more than one $bgcolor command ",
			"in this section.",
			NULL
		);


		CurrentSection->style.bgcolor = Color(
			(yyvsp[(1) - (3)]).line, "$bgcolor", (yyvsp[(2) - (3)]).str
		);
		
		FreeMem((yyvsp[(2) - (3)]).str);
		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 81:
#line 1622 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		OutputString("<big>");
		PushPending((yyvsp[(1) - (1)]).line, "$big");

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 82:
#line 1633 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str == NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		OutputString("</big>");
		PopPending((yyvsp[(3) - (3)]).line, "$big");

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 83:
#line 1646 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		OutputString("<b>");
		PushPending((yyvsp[(1) - (1)]).line, "$bold");

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 84:
#line 1657 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str == NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		OutputString("</b>");
		PopPending((yyvsp[(3) - (3)]).line, "$bold");

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 85:
#line 1670 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		if( TableLevel == 0 ) fatalomh(
			"$cnext or $cend command in line ",
			int2str((yyvsp[(1) - (1)]).line),
			"\nis not between a $table command ",
			"and its corresponding $tend command",
			NULL
		);
		assert( PreviousOutputWasHeading == 0 );

		OutputString("</td>");
		FormatOutput("<td align='%s' ", HorizontalAlign);
		FormatOutput(" valign='%s'>\n", VerticalAlign);

		PopPending( (yyvsp[(1) - (1)]).line, "$cnext");
		PushPending((yyvsp[(1) - (1)]).line, "$cnext");

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 86:
#line 1694 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );
		(yyval) = (yyvsp[(1) - (1)]); 
	;}
    break;

  case 87:
#line 1698 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );
		(yyval) = (yyvsp[(1) - (1)]); 
	;}
    break;

  case 88:
#line 1705 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		// do not need extra new line after previous heading
		if( PreviousOutputWasHeading )
			PreviousOutputWasHeading = 0;

		OutputString("<center>");
		PushPending((yyvsp[(1) - (1)]).line, "$center");

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 89:
#line 1720 "omhelp.y"
    {	assert( (yyvsp[(2) - (3)]).str == NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		OutputString("</center>");
		PopPending((yyvsp[(3) - (3)]).line, "$center");

		// the end of centering starts a new line
		ConvertAddPrevious(1);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 90:
#line 1735 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		(yyval).str  = str_alloc("$contents");
		(yyval).line = (yyvsp[(1) - (1)]).line;
	;}
    break;

  case 91:
#line 1741 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		(yyval).str  = str_alloc("$childtable");
		(yyval).line = (yyvsp[(1) - (1)]).line;
	;}
    break;

  case 92:
#line 1750 "omhelp.y"
    {
		CrossReference *C;
		char           *number  = NULL;
		char           *printid = NULL;
		char           *converted;

		assert( (yyvsp[(1) - (1)]).str != NULL );

		// do not need extra new line after previous heading
		if( PreviousOutputWasHeading )
			PreviousOutputWasHeading = 0;

		// set the current heading
		SetHeading("Contents");

		if( ConvertPreviousNewline() < 2 )
			ConvertForcedNewline(2 - ConvertPreviousNewline() );

		number  = SectionNumber(CurrentSection);
		assert( *( HeadingAndSubPrintId() ) == '.' );

		if( number[0] == '\0' )
			printid = strjoin(number, HeadingAndSubPrintId()+1);
		else	printid = strjoin(number, HeadingAndSubPrintId());

		OutputString("<b><big>");
		if( PrintableOmhelp() )
		{	FormatOutput2(
				"<a name=\"%s\" id=\"%s\">", 
				printid,
				printid
			);
			OutputString(printid);
			OutputString(": ");
		}
		else
		{	converted = ConvertInternalString(
				HeadingAndSubHeading()
			);
			FormatOutput2(
				"<a name=\"%s\" id=\"%s\">", 
				converted,
				converted
			);
			FreeMem(converted);
		}

		outtext((yyvsp[(1) - (1)]).line, "Contents", 0);
		OutputString("</a></big></b>\n");
		ConvertForcedNewline(1);

		// defined cross reference point
		C = DefineCrossReference(
			CurrentSection->tag, 
			HeadingAndSubHeading(),
			InputName(),
			iFrame,
			printid
		);
		assert( C != NULL);
		FreeMem(number);
		FreeMem(printid);

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 93:
#line 1819 "omhelp.y"
    {
		char       *p;
		char       *name;
		char       del;
		SectionInfo *F;
		SectionInfo *list;

		assert( (yyvsp[(1) - (3)]).str != NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		F = CurrentSection->children;
		while( IsAutomaticSection(F) )
			F = F->next;
		if( F != NULL ) fatalomh(
			"Invalid ",
			(yyvsp[(1) - (3)]).str,
			" command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nThere was a previous ",
			"$contents, $children, or $childtable",
			"\ncommannd in this section",
			NULL
		);

		// delimiter is first character in text;
		del        = *((yyvsp[(2) - (3)]).str);
	       
		// last character in text
		p          = (yyvsp[(2) - (3)]).str + strlen((yyvsp[(2) - (3)]).str) - 1;
		if( *p != del ) fatalomh(
			"In delimiter sequence following ",
			(yyvsp[(1) - (3)]).str,
			" command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			NULL
		);

		// add the files to the list in reverse order
		// because we add at the front of the list
		list       = NULL;
		while(p - 1 > (yyvsp[(2) - (3)]).str)
		{	// end of this file name
			*p = '\0';
			
			// find begining of this file name
			while( *p != del ) p--;
			
			// skip white space
			name = p + 1;
			while( isspace(*name) ) name++;

			// make sure name is not empty
			if( *name == '\0' ) fatalomh(
				"There is only white space between two\n",
				"of the delimiters in the\n",
				(yyvsp[(1) - (3)]).str,
				" command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				NULL
			);
			
			// add to the file list
			F = SectionInfoNew(SectionTree, name);

			// if the file does not exist, generate error
			// message when it is specified and not later
			InputSearch(F->root, F->ext);
			
			// link it up at the front of the list of children
			F->next = list;
			if( list != NULL )
				list->previous  = F;
			F->parent   = CurrentSection;
			list = F;
		}	
		
		// link this list to parent
		if( CurrentSection->children == NULL )
			CurrentSection->children = list;
		else
		{	F = CurrentSection->children;
			assert( IsAutomaticSection(F) );

			while( F->next != NULL )
				F = F->next;
			F->next        = list;
			list->previous = F;
		}

		if( strcmp((yyvsp[(1) - (3)]).str, "$children") == 0 )
			OutputString("<CHILDREN>");
		else if( strcmp((yyvsp[(1) - (3)]).str, "$contents") == 0 )
			OutputString("<CONTENTS>");
		else if( strcmp((yyvsp[(1) - (3)]).str, "$childtable") == 0 )
			OutputString("<CHILDTABLE>");
		else	assert(0);

		
		FreeMem((yyvsp[(1) - (3)]).str);
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval).str  = NULL;
		(yyval).line = (yyvsp[(1) - (3)]).line;
	;}
    break;

  case 94:
#line 1928 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		RootHasChildren = 1;

		(yyval).str  = str_alloc("$children");
		(yyval).line = (yyvsp[(1) - (1)]).line;
	;}
    break;

  case 95:
#line 1936 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str != NULL );

		RootHasChildren = 1;

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 96:
#line 1945 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		(yyval).str  = str_alloc("$cindex");
		(yyval).line = (yyvsp[(1) - (1)]).line;
	;}
    break;

  case 97:
#line 1951 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		(yyval).str  = str_alloc("$mindex"); 
		(yyval).line = (yyvsp[(1) - (1)]).line;
	;}
    break;

  case 98:
#line 1957 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		(yyval).str  = str_alloc("$index"); 
		(yyval).line = (yyvsp[(1) - (1)]).line;
	;}
    break;

  case 99:
#line 1966 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 100:
#line 1969 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );
	
		Cmark  = *((yyvsp[(2) - (3)]).str);
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 101:
#line 1983 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		OutputString("<code><font color=\"");
		OutputString(CodeColor);
		OutputString("\">");
		PushPending((yyvsp[(1) - (1)]).line, "$code");

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 102:
#line 1996 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str == NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		OutputString("</font></code>");
		PopPending((yyvsp[(3) - (3)]).line, "$code");

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 103:
#line 2009 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 104:
#line 2012 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		FreeMem(CodeColor);
		CodeColor = Color((yyvsp[(1) - (3)]).line, "$codecolor", (yyvsp[(2) - (3)]).str);

		FreeMem((yyvsp[(2) - (3)]).str);
		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 105:
#line 2027 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 106:
#line 2030 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		// do not need extra new line after previous heading
		if( PreviousOutputWasHeading )
			PreviousOutputWasHeading = 0;

		SkipCodep((yyvsp[(2) - (3)]).line, (yyvsp[(2) - (3)]).str);

		if( ExecuteFile != NULL )
		{	char *text;
			int len;

			FreeMem(ExecuteFile);
			ExecuteFile = NULL;

			text = str_alloc((yyvsp[(2) - (3)]).str);
			len  = strlen(text);

			assert( len > 1 );
			assert( text[0] == '\n' );
			assert( text[len-1] == '\n' );
			assert( ExecuteNextFile() != NULL );

			text[len-1] = '\0';
			ExecuteWriteFile(text + 1);

			FreeMem(text);
		}

		OutputString("<code><font color=\"");
		OutputString(CodeColor);
		OutputString("\">");
		OutputString("\n");
		outtext((yyvsp[(2) - (3)]).line, (yyvsp[(2) - (3)]).str, 1);
		OutputString("\n");
		OutputString("</font></code>\n");
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 107:
#line 2077 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 108:
#line 2080 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 109:
#line 2092 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 110:
#line 2095 "omhelp.y"
    {	char *text;
		char *tag;
		char *head;
		char *subhead;
		char *frame;
		char *external;
		CrossReference *C;

		int checkspell;
		int ntoken;
		int i, j;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		if( PreviousOutputWasHeading )
		{	ConvertForcedNewline(1);
			PreviousOutputWasHeading = 0;
		}
		

		// split text into tokens
		ntoken = SplitText((yyvsp[(1) - (3)]).line, "$cref", (yyvsp[(2) - (3)]).str);
		if( ntoken > 4 ) fatalomh(
			"At $cref command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nMore than 5 delimiters in $cref command",
			NULL
		);
		
		// text for reference
		text = (yyvsp[(2) - (3)]).str + 1;
		tag  = text + strlen(text) + 1;
		UniformWhiteSpace(text);
		if( text[0] == '\0' ) fatalomh(
			"At $cref command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nthe text portion is only white space",
			NULL
		);

		// tag
		if( ntoken >= 2 )
		{	head = tag + strlen(tag) + 1;
			UniformWhiteSpace(tag);
			if( tag[0] == '\0' ) fatalomh(
				"At $cref command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\nthe tag portion is only white space",
				NULL
			);
		}
		else
		{	head = ""; // avoid unitialized warning
			tag = text;
		}

		// head 
		if( ntoken >= 3 )
		{	subhead = head + strlen(head) + 1;
			UniformWhiteSpace(head);
			if( head[0] == '\0' ) fatalomh(
				"At $cref command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\nthe head portion is only white space",
				NULL
			);
		}
		else
		{	subhead = ""; // avoid unitialized warning
			head    = "";
		}

		// subhead
		if( ntoken >= 4 )
		{	UniformWhiteSpace(subhead);
			if( subhead[0] == '\0' ) fatalomh(
				"At $cref command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\nthe subhead portion is only white space",
				NULL
			);
		}
		else	subhead = "";

		// target frame (part of xref) has been deprecricated.
		frame = "";

		// this is not an external reference
		external = "false";

		// attach the subheading to the heading
		if( subhead[0] != '\0' )
		{	assert( subhead >=  head + strlen(head) + 1);
			i         = strlen(head);
			j         = 0;
			head[i++] = '.';
			while( subhead[j] != '\0' )
				head[i++] = subhead[j++];	
			head[i] = '\0';
		}

		// output the cross reference jump without spell checking
		checkspell = CheckSpell;
		CheckSpell = 0;
		HrefOutputPass1(tag, head, external, frame);

		// output other information with spell checking
		if( ntoken >= 2 )
			CheckSpell = checkspell;
		
		OutPre((yyvsp[(2) - (3)]).line, text);
		HrefEnd("\n");
		
		// search for this cross reference
		C = FindCrossReference(tag, head);
		if( C == NULL )
			C = CreateCrossReference(tag, head, InputName());
		assert( C != NULL );

		// restore spell checking to initial setting
		CheckSpell = checkspell;
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 111:
#line 2227 "omhelp.y"
    {	time_t     time_t_time;
		struct tm     *tm_time;
		char        *char_time;
		char          date[13];
		int                  i;

		assert( (yyvsp[(1) - (1)]).str == NULL );

		if( PreviousOutputWasHeading )
		{	ConvertForcedNewline(1);
			PreviousOutputWasHeading = 0;
		}

		time(&time_t_time);
		tm_time = localtime( &time_t_time );
		char_time = asctime( tm_time);

		// month space day (3 + 1 + 2 characters)
		for(i = 0; i < 6; i++)
			date[i] = char_time[i + 4];

		// comma space year end
		date[6] = ',';
		date[7] = ' ';
		for(i = 0; i < 4; i++)
			date[i + 8] = char_time[i + 20];
		date[12] = '\0';

		OutputString(date);

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 112:
#line 2264 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 113:
#line 2267 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		Dollar = *((yyvsp[(2) - (3)]).str);
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 114:
#line 2281 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		// do not need extra new line after previous heading
		if( PreviousOutputWasHeading )
			PreviousOutputWasHeading = 0;

		// make sure there was a section command
		if( CurrentSection->title == NULL ) fatalomh(
			"There was no $section command\n",
			"between the $end command on line ",
			int2str((yyvsp[(1) - (1)]).line),
			" and the previous $begin command",
			NULL
		);

		// make sure maximum frame referenced was valid
		assert( MaxFrame <= iFrame || MaxFrameFile != NULL );
		if( MaxFrame > iFrame ) fatalomh(
			"Frame number ",
			int2str(MaxFrame),
			" does not exist in the current section\n",
			"This frame is referenced in $xref command in line ",
			int2str(MaxFrameLine),
			"\nof file ",
			MaxFrameFile,
			NULL
		);

		// make sure any execute has been written
		if( ExecuteFile != NULL ) fatalomh(
			"No $codep command follows the $execute command\n",
			"in line ",
			int2str(ExecuteLine),
			" of file ",
			ExecuteFile,
			NULL
		);

		// check there are no pending commands
		if( NumberPending() > 0 )
			OmhPendingError((yyvsp[(1) - (1)]).line, "$end");

		// the check above should have asserted the following
		assert( TableLevel == 0);
		assert( ListLevel  == 0);

		// copy default style from starting file to values not set
		if( CurrentSection == SectionTree )
		{	SectionInfo *Contents = CurrentSection->children;
			assert(Contents != NULL );
			SectionDefaultStyle(Contents, SectionTree);

			// keep macros defined at the root level
			LatexMacroKeep();
		}
		else
		{	SectionDefaultStyle(CurrentSection, SectionTree);
			LatexMacroFree();
			LatexMacroKeep();
		}

		// get the keywords for this section
		assert( CurrentSection->keywords == NULL );
		CurrentSection->keywords = SearchGetKeywords();

		// terminate search keys for current section
		SearchEnd();

		// output name of current input file
		if( DebugOmhelp ) FormatOutput2(
			"\n<hr%sInput File: %s\n", 
			Internal2Out("SelfTerminateCmd"),
			InputName()
		);

		// keep track of how many end commands
		EndCount++;

		FreeMem( MaxFrameFile );
		FreeMem( ErrorColor   );
		FreeMem( CodeColor    );

		MaxFrameFile = NULL;
		ErrorColor   = NULL;
		CodeColor    = NULL;
		
		PopOutput();
		
		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 115:
#line 2376 "omhelp.y"
    {	// end of an input file

		SectionInfo *S;
		int          done;

		// initialize I to avoid warning
		// (compiler does not know it will be reset before used)
		SectionInfo *I = NULL;

		assert( (yyvsp[(1) - (1)]).str != NULL );

		if( IncludeFrom != NULL )
		{	// not much to do in include file case
			InputPop();

			FreeMem(IncludeFrom);
			IncludeFrom = NULL;

			// no need for the previous command key character
			FreeMem((yyvsp[(1) - (1)]).str);
			(yyvsp[(1) - (1)]).str = NULL;
		}
		else
		{
		// not include file case ***********************************
		
		if( BeginCount == 0 ) fatalomh(
			"No ",
			(yyvsp[(1) - (1)]).str,
			"begin commands in current input file",
			NULL
		);

		// lexomh ignores all commands until $begin is found
		assert( BeginCount >= EndCount );

		if( BeginCount > EndCount ) fatalomh(
			"There are more ",
			(yyvsp[(1) - (1)]).str,
			"begin than ",
			(yyvsp[(1) - (1)]).str,
			"end commmands\n",
			"in the current input file",
			NULL
		);
		assert( PreviousOutputWasHeading == 0 );

		// done with the previous command key character
		FreeMem((yyvsp[(1) - (1)]).str);
		(yyvsp[(1) - (1)]).str = NULL;

		// done with this input file
		InputPop();

		// pointers relative to current file
		S = CurrentSection;

		// back up at this level because one input file can have
		// multiple sections in it
		while( S->previous != NULL )
			S = S->previous;
		
		// check for an unread input file  (skip automatic sections)
		done = 1;
		while( done && S != NULL )
		{	
			// check children first
			I    = S->children;
			while( IsAutomaticSection(I) )
				I = I->next;
			done = I == NULL || I->tag != NULL;

			// check siblings next
			if( done )
			{	I    = S->next;
				while( IsAutomaticSection(I) )
					I = I->next;
				done = I == NULL || I->tag != NULL;
			}

			if( done )
			{
				if( S->next != NULL )
				{	// move forward at current level
					// undoing the back up above
					S = S->next;
				}
				else
				{	// completed this entire level
					S = S->parent;
					assert( S == NULL ||
						SectionTagNotDefined(
							S->children
						) == NULL 
					);
				}
			}
		}	
				
		// erase the current heading setting
		InitializeHeading();

		if( I != NULL )
		{	// start reading next file
			PushOmhInput(I);
			CurrentSection = I;

		}
		else
		{	
			if( RootHasChildren )
				Appendices();
			FinishUp();
			return(1);
		}

		// end of not include file case *****************************
		}

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 116:
#line 2501 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 117:
#line 2504 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		FreeMem(ErrorColor);
		ErrorColor = Color((yyvsp[(1) - (3)]).line, "$errorcolor", (yyvsp[(2) - (3)]).str);

		FreeMem((yyvsp[(2) - (3)]).str);
		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 118:
#line 2518 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 119:
#line 2521 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		Escape = *((yyvsp[(2) - (3)]).str);
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 120:
#line 2536 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 121:
#line 2539 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		if( PreviousOutputWasHeading )
		{	ConvertForcedNewline(1);
			PreviousOutputWasHeading = 0;
		}

		// check for already set
		if( ExecuteFile !=  NULL ) fatalomh(
			"There is no $codep command between the\n",
			"$execute command in line ",
			int2str(ExecuteLine),
			" of file ",
			ExecuteFile,
			"\nand the $execute command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			" of file ",
			InputName(),
			NULL
		);
		
	       	// file name for error reporting
		ExecuteFile = str_alloc(InputName());
		ExecuteLine = (yyvsp[(1) - (3)]).line;

		// file name to write to
		assert( CurrentSection->tag != NULL );
		ExecuteSetFile((yyvsp[(2) - (3)]).str, CurrentSection->tag);
		
		// insert link to execute
		FormatOutput("<EXECUTE=\"%s\">", (yyvsp[(2) - (3)]).str);
	
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 122:
#line 2582 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 123:
#line 2585 "omhelp.y"
    {
		int above;
		int below;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		// do not need extra new line after previous heading
		if( PreviousOutputWasHeading )
			PreviousOutputWasHeading = 0;

		// check there are no pending commands
		if( NumberPending() > 0 )
			OmhPendingError((yyvsp[(1) - (3)]).line, "$fend");

		if( ! (PrintableOmhelp() | NoFrame() ) )
		{
			if( iFrame >= MAX_FRAME ) fatalomh(
				"\nThere are more than ",
				int2str(MAX_FRAME),
				" frames requested for this section\n",
				"OMhelp Cannot satisfy the $fend request in ",
				"line ",
				int2str((yyvsp[(1) - (3)]).line),
				NULL
			);
	
			above   = atoi((yyvsp[(2) - (3)]).str);
			if( above < 5 ) fatalomh(
				"In the $fend command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\nthe requested frame size ",
				"is less than 5 percent\n",
				NULL
			);
	
			below = CurrentSection->Frame[iFrame - 1] - above;
			if( below < 5 ) fatalomh(
				"At the $fend command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\nThe sum of the frame sizes in this ",
				"$fend command and in the previous\n",
				"$fend commands in this section ",
				"is greater than 95 percent",
				NULL
			);
	
			CurrentSection->Frame[iFrame - 1] = above;
			CurrentSection->Frame[iFrame]     = below;
			CurrentSection->nFrame = iFrame   = iFrame + 1;
			
			OutputString("\n<FEND>\n");

			// a new frame separates as well as two newlines
			ConvertAddPrevious(2);
			
	
		}
		else
		{	// use two newlines to separate in printable version
			ConvertForcedNewline( 2 - ConvertPreviousNewline() );
		}
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 124:
#line 2656 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		OutputString("<code>");
		PushPending((yyvsp[(1) - (1)]).line, "$fixed");

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 125:
#line 2667 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str == NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		OutputString("</code>");
		PopPending((yyvsp[(3) - (3)]).line, "$fixed");

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 126:
#line 2680 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 127:
#line 2683 "omhelp.y"
    {	
		CrossReference *C;
		char           *noEscape;
		char           *converted;
		char           *number = NULL;
		char           *printid = NULL;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		// do not need extra new line after previous heading
		if( PreviousOutputWasHeading )
			PreviousOutputWasHeading = 0;

		if( TableLevel > 0 ) fatalomh(
			"The $head command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			" is inside a table; i.e.,\n",
			"between a $table and the corresponding $tend",
			NULL
		);
 		// make sure no # characters in heading
 		if( strchr((yyvsp[(2) - (3)]).str, '#') != NULL ) fatalomh(
 			"$head command in line ",
 			int2str((yyvsp[(1) - (3)]).line),
 			" has heading\n",
 			(yyvsp[(2) - (3)]).str,
 			"\nThe character '#' is not allowed in headings",
 			NULL
 		);
 
		// version of heading without escape characters
		noEscape = str_alloc((yyvsp[(2) - (3)]).str);
		if( MindexHead )
			StrRemove(noEscape, Escape);

		// convert to unifrom white space format
		UniformWhiteSpace(noEscape);

		if( ConvertPreviousNewline() < 2 )
			ConvertForcedNewline(2 - ConvertPreviousNewline() );

		// set corresponding current heading
		SetHeading(noEscape);

		number  = SectionNumber(CurrentSection);
		assert( *( HeadingAndSubPrintId() ) == '.' );
		if( number[0] == '\0' )
			printid = strjoin(number, HeadingAndSubPrintId()+1);
		else	printid = strjoin(number, HeadingAndSubPrintId() );

		OutputString("<b><big>");
		if( PrintableOmhelp() )
		{	FormatOutput2(
				"<a name=\"%s\" id=\"%s\">", 
				printid,
				printid
			);
			OutputString(printid);
			OutputString(": ");
		}
		else
		{	converted = ConvertInternalString(
				HeadingAndSubHeading()
			);
			FormatOutput2(
				"<a name=\"%s\" id=\"%s\">", 
				converted,
				converted
			);
			FreeMem(converted);
		}

		outtext((yyvsp[(2) - (3)]).line, noEscape, 0);
		OutputString("</a></big></b>\n");

		// defined cross reference point
		C = DefineCrossReference(
			CurrentSection->tag, 
			HeadingAndSubHeading(),
			InputName(),
			iFrame,
			printid
		);
		assert( C != NULL );
		FreeMem(number);
		FreeMem(printid);

		if( MindexHead )
		{	char *lower = StrLowAlloc((yyvsp[(2) - (3)]).str);

			// add keywords to search for this section
			SearchKeywords(lower, Escape);
		
			MultipleIntoIndex(
				lower, 
				CurrentSection->tag, 
				HeadingAndSubHeading(),
				Escape
			);

			FreeMem(lower);
		}

		FreeMem(noEscape);
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);

		PreviousOutputWasHeading = 1;
	;}
    break;

  case 128:
#line 2798 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 129:
#line 2801 "omhelp.y"
    {	char *url;
		char *frame;
		char *link;
		char *tag;
		char *heading;

		int checkspell;
		int ntoken;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		if( PreviousOutputWasHeading )
		{	ConvertForcedNewline(1);
			PreviousOutputWasHeading = 0;
		}
		
		// initial state of spell checker
		checkspell = CheckSpell;

		// split text into tokens
		ntoken = SplitText((yyvsp[(1) - (3)]).line, "$href", (yyvsp[(2) - (3)]).str);
		if( ntoken > 3 ) fatalomh(
			"In the $href command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nTo many delimiters in the delimiter sequence",
			NULL
		);
		
		// internet address for reference
		url = (yyvsp[(2) - (3)]).str + 1;

		// make sure url is not empty
		if( WhiteSpace(url) ) fatalomh(
			"In the $href command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nOnly white space between first 2 delimiters",
			NULL
		);

		// make sure not using back slashes in address
		// because they do not work when displaying on Unix
		if( strchr(url, '\\') != NULL ) fatalomh(
			"In the $href command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nMust use \"/\" in place of \"\\\" in uri",
			NULL
		); 

		// linking text for reference
		if( ntoken < 2 )
			link = "";
		else	link = url + strlen(url) + 1;

		// displaying frame for the reference
		if( ntoken < 3 || PrintableOmhelp() )
			frame = "";
		else	frame = link + strlen(link) + 1;

		// clip leading and trailing white space in all arugments
		ClipWhiteSpace(url);
		if( ntoken >= 2 )
			ClipWhiteSpace(link);
		if( ntoken >= 3 && (! PrintableOmhelp() ) )
			ClipWhiteSpace(frame);


		// Split the URL to a file and anchor in that file
		tag     = str_alloc(url);
		heading = strchr(tag, '#');
		if( heading != NULL )
		{	*heading = '\0';
			heading++;
		}
		else	heading = "\0"; 
		

		// output the internet reference
		CheckSpell = 0;
		HrefOutputPass1(tag, heading, "true", frame);
		HrefAddList(
			CurrentSection->tag,
			HeadingAndSubHeading(),
			tag,
			heading
		);
		
		if( ntoken < 2 )
			OutPre((yyvsp[(2) - (3)]).line, url);
		else	OutPre((yyvsp[(2) - (3)]).line, link);
		HrefEnd("\n");

		if( ntoken >= 2 && PrintableOmhelp() )
		{	OutputString(" (");
			outtext((yyvsp[(2) - (3)]).line, url, 0);
			OutputString(") ");
		}
		
		CheckSpell = checkspell;
		FreeMem(tag);
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 130:
#line 2910 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );
	
		(yyval).str  = str_alloc("$icon");
		(yyval).line = (yyvsp[(1) - (1)]).line;

	;}
    break;

  case 131:
#line 2917 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		(yyval).str  = str_alloc("$image");
		(yyval).line = (yyvsp[(1) - (1)]).line;
	;}
    break;

  case 132:
#line 2927 "omhelp.y"
    {	

		char *root;
		char *ext;
		char *name;
		char *fullname;

		char *localname;

		int  i;

		assert( (yyvsp[(1) - (3)]).str != NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );


		// Brad Bell: 07/19/02
		// removed so no warning occurs
		// const char *path;

		if( (yyvsp[(2) - (3)]).str[0] == '_' ) fatalomh(
			"The file name following ",
			(yyvsp[(1) - (3)]).str,
			" command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nbegins with the \"_\" character",
			NULL
		);

		// determine root and extension
		InputSplitName(&root, &ext, (yyvsp[(2) - (3)]).str);

		// check for case of default extension
		if( ext[0] == '\0' )
		{	FreeMem(ext);
			ext = str_alloc(".gif");
		}
		else if( stricmp(
		ext, Internal2Out("OutputExtension") ) == 0 ) fatalomh( 
				"The file name following ",
				(yyvsp[(1) - (3)]).str,
				" command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\nuses ",
				Internal2Out("OutputExtension"),
				" for its file extension",
				NULL
		);
		
		
		// Brad Bell: 07/28/01
		// The following line generates a const qualifier warning 
		// from the MS compiler. It looks to me that the compiler is
		// wrong.
		// path     = InputSearch(root, ext);

		// file name including extension
		name     = strjoin(root, ext);
		fullname = strjoin( InputSearch(root, ext) , name);
	
		// determine the local file name
		i = strlen(fullname) - 1;
		while( i > 0 && fullname[i] != '\\' && fullname[i] != '/' )
			i--;
			
		// make a local copy of the file
		if( i > 0 )
		{	localname = fullname + i + 1;
		}
		else	localname = fullname;
		localname = StrLowAlloc(localname);
		copyfile(localname, fullname);

		FreeMem(fullname);
		FreeMem(name);
		FreeMem(ext);
		FreeMem(root);


		if( strcmp( (yyvsp[(1) - (3)]).str, "$icon" ) == 0 )
		{

			if( PreviousOutputWasHeading )
			{	ConvertForcedNewline(1);
				PreviousOutputWasHeading = 0;
			}

			FormatOutput2(
				"<img src=\"%s\" valign=\"top\"%s\n",
				localname,
				Internal2Out("SelfTerminateCmd")
			);
		}
		else if( strcmp( (yyvsp[(1) - (3)]).str, "$image" ) == 0 )
		{

			// do not need extra new line after previous heading
			if( PreviousOutputWasHeading )
				PreviousOutputWasHeading = 0;

			OutputString("<center>");
			FormatOutput2(
				"<img src=\"%s\"%s\n", 
				localname,
				Internal2Out("SelfTerminateCmd")
			);
			OutputString("</center>");

			// the end of centering starts a new line
			ConvertAddPrevious(1);
		}
		else	assert(0);

		FreeMem((yyvsp[(1) - (3)]).str);
		FreeMem((yyvsp[(2) - (3)]).str);
		FreeMem(localname);

		(yyval).str  = NULL;
		(yyval).line = (yyvsp[(1) - (3)]).line;
	;}
    break;

  case 133:
#line 3051 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 134:
#line 3054 "omhelp.y"
    {	char  *root;
		char  *ext;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		if( IncludeFrom != NULL ) fatalomh(
			"Cannot use $include command on line ",
			int2str((yyvsp[(1) - (3)]).line),
			" because\n",
			InputName(),
			" was included by $include \n",
			"in line ",
			int2str(IncludeLine),
			" of ",
			IncludeFrom,
			NULL
		);
		IncludeFrom = str_alloc(InputName());
		IncludeLine = (yyvsp[(1) - (3)]).line;

		root = str_alloc((yyvsp[(2) - (3)]).str);

		// determine the start of the extension
		ext = root + strlen(root) - 1;
		while( (ext > root) & (*ext != '.') )
			ext--;

		// separate root and extension
		if( ext > root )
		{	*ext++ = '\0';
			ext    = strjoin(".", ext);
		}
		else	ext    = str_alloc("");

		// set input file 
		InputPush(root, ext, -1);

		FreeMem(ext);
		FreeMem(root);

		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 135:
#line 3105 "omhelp.y"
    {	char *text = (yyvsp[(2) - (3)]).str;
		int line   = (yyvsp[(1) - (3)]).line;


		assert( (yyvsp[(1) - (3)]).str != NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		// add keywords to search for this section
		SearchKeywords(text, Escape);
		
		// check for seplling error
		if( CheckSpell )
		{	
			const char *s = (yyvsp[(2) - (3)]).str;
			int i, j;
			int nchar;

			i = 0;
			j = 0;
			while( SpellingError(s + i, &nchar) != NULL )
			{	i = SpellingError(s + i, &nchar) - s;

				// advance line counter to spelling error
				while( j < i )
				{	line += (s[j] == '\n');
					j++;
				}
				

				// begin standard output version of error
				printf(
					"\nOMhelp Warning: spelling "
					"in line %d of file %s: ",
					line,
					InputName()
				);

				// begin browser version of error
				if( ConvertPreviousNewline() == 0 )
					ConvertForcedNewline(1);
				OutputString("<font color=\"");
				OutputString(ErrorColor);
				OutputString("\">");

				assert( nchar > 0 );
				while( nchar-- )
				{	if( isspace(s[i]) )
					{	printf(" ");
						ConvertOutputCh(' ', 0);
					}
					else
					{	printf("%c", s[i]);
						ConvertOutputCh(s[i], 0);
					}
					i++;
				}

				// end standard output version of error
				printf("\n");

				// end browser version of error
				OutputString("</font>");
				ConvertForcedNewline(1);
			}
		}
		
	
		// new entry
		if( strcmp((yyvsp[(1) - (3)]).str, "$index") == 0 ) InsertInIndex(
			text, 
			CurrentSection->tag, 
			HeadingAndSubHeading(),
			Escape
		);
		else if( strcmp((yyvsp[(1) - (3)]).str, "$cindex") == 0 ) CycleIntoIndex(
			text, 
			CurrentSection->tag, 
			HeadingAndSubHeading(),
			Escape
		);
		else if( strcmp((yyvsp[(1) - (3)]).str, "$mindex") == 0 ) MultipleIntoIndex(
			text, 
			CurrentSection->tag, 
			HeadingAndSubHeading(),
			Escape
		);
		else	assert(0);

		FreeMem((yyvsp[(1) - (3)]).str);
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval).str  = NULL;
		(yyval).line = (yyvsp[(1) - (3)]).line;
	;}
    break;

  case 136:
#line 3204 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		OutputString("<i>");
		PushPending((yyvsp[(1) - (1)]).line, "$italic");
		ItalicCount++;

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 137:
#line 3216 "omhelp.y"
    {
		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str == NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		OutputString("</i>");
		PopPending((yyvsp[(3) - (3)]).line, "$italic");
		ItalicCount--;

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 203:
#line 3296 "omhelp.y"
    {	(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 204:
#line 3302 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 205:
#line 3305 "omhelp.y"
    {
		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		if( strcmp(".xml", Internal2Out("OutputExtension") ) == 0 )
		{	int BlockDisplay;

			LatexLexPut((yyvsp[(2) - (3)]).line, (yyvsp[(2) - (3)]).str);
			BlockDisplay = texparse();

			ConvertAddPrevious( - ConvertPreviousNewline() );
			if( BlockDisplay )
				ConvertAddPrevious(1);

			// note texparse uses PreviousOmhelpOutputWasHeading()
			PreviousOutputWasHeading = 0;
		}
		else
		{	int checkspell = CheckSpell;
			CheckSpell     = 0;

			assert( strcmp(".htm", 
				Internal2Out("OutputExtension") ) == 0 );


			// if output begins with a preformatted new line
			// do not need an extra one to for previous heading
			if( PreviousOutputWasHeading )
			{	char *s = (yyvsp[(2) - (3)]).str;
				char ch = *s++;

				int newline = 0;

				while( isspace(ch) )
				{	newline = newline || (ch == '\n');
					ch = *s++;
				}

				if( ! newline )
					ConvertForcedNewline(1);

				PreviousOutputWasHeading = 0;
			}

			OutputString("<code>\n");
			OutPre((yyvsp[(2) - (3)]).line, (yyvsp[(2) - (3)]).str);
			OutputString("</code>\n");

			CheckSpell = checkspell;
		}
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 206:
#line 3366 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		if( ListLevel <= 0 ) fatalomh(
			"There is no matching $list command preceeding\n",
			"the $lend command in line ",
			int2str((yyvsp[(1) - (1)]).line),
			NULL
		);
		assert( PreviousOutputWasHeading == 0 );

		ListLevel--;
		if( ListOrdered[ListLevel] )
			OutputString("</li></ol>\n");
		else	OutputString("</li></ul>\n");

		PopPending((yyvsp[(1) - (1)]).line, "$list");
		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 207:
#line 3387 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 208:
#line 3390 "omhelp.y"
    {	// initalize cmd to avoid warning
		// (compiler does not know fatalerr will not return)
		char *cmd = NULL;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );


		// do not need extra new line after previous heading
		if( PreviousOutputWasHeading )
			PreviousOutputWasHeading = 0;

		if( ListLevel == MAX_LIST_LEVEL ) fatalomh(
			"At $list command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nMore than ",
			int2str(MAX_LIST_LEVEL),
			" levels of nested lists requested",
			NULL
		);

		ListOrdered[ListLevel]= 1;

		if( strcmp((yyvsp[(2) - (3)]).str, "disk") == 0 )
		{	cmd  = "<ul type=\"disk\"><li>";
			ListOrdered[ListLevel] = 0;
		}
		else if( strcmp((yyvsp[(2) - (3)]).str, "circle") == 0 )
		{	cmd  = "<ul type=\"circle\"><li>";
			ListOrdered[ListLevel] = 0;
		}
		else if( strcmp((yyvsp[(2) - (3)]).str, "square") == 0 )
		{	cmd  = "<ul type=\"square\"><li>";
			ListOrdered[ListLevel] = 0;
		}
		else if( strcmp((yyvsp[(2) - (3)]).str, "number") == 0 )
			cmd  = "<ol type=\"1\"><li>";
		else if( strcmp((yyvsp[(2) - (3)]).str, "alpha") == 0 )
			cmd  = "<ol type=\"a\"><li>";
		else if( strcmp((yyvsp[(2) - (3)]).str, "Alpha") == 0 )
			cmd  = "<ol type=\"A\"><li>";
		else if( strcmp((yyvsp[(2) - (3)]).str, "roman") == 0 )
			cmd  = "<ol type=\"i\"><li>";
		else if( strcmp((yyvsp[(2) - (3)]).str, "Roman") == 0 )
			cmd  = "<ol type=\"I\"><li>";
		else fatalomh(
			"At $list command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\n",
			(yyvsp[(2) - (3)]).str,
			" is not a valid marker for a $list command",
			NULL
		);

		ListLevel++;	

		OutputString(cmd);

		FreeMem((yyvsp[(2) - (3)]).str);

		PushPending((yyvsp[(1) - (3)]).line, "$list");

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 209:
#line 3459 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		if( ListLevel == 0 ) fatalomh(
			"The $lnext command in line ",
			int2str((yyvsp[(1) - (1)]).line),
			"\nis not inside of a list; i.e.,\n",
			"not between a $list and the corresponding $lend",
			NULL
		);
		assert( PreviousOutputWasHeading == 0 );

		OutputString("</li><li>\n");

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 210:
#line 3478 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 211:
#line 3481 "omhelp.y"
    {	int   ntoken;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		// split text into tokens
		ntoken = SplitText((yyvsp[(1) - (3)]).line, "$math", (yyvsp[(2) - (3)]).str);


		// if output begins with a preformatted new line
		// do not need an extra one to for previous heading
		if( PreviousOutputWasHeading )
		{	char *s = (yyvsp[(2) - (3)]).str + 1;
			char ch = *s++;

			int newline = 0;

			while( isspace(ch) )
			{	newline = newline || (ch == '\n');
				ch = *s++;
			}

			if( ! newline )
				ConvertForcedNewline(1);

			PreviousOutputWasHeading = 0;
		}

		OutputMath(ntoken, (yyvsp[(2) - (3)]).str + 1, Escape, ItalicCount > 0);
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 212:
#line 3521 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 213:
#line 3524 "omhelp.y"
    {	char *tag;
		char *next;
		CrossReference *C;
		int nref;
		int checkspell;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		if( PreviousOutputWasHeading )
		{	ConvertForcedNewline(1);
			PreviousOutputWasHeading = 0;
		}
		
		// suspend spell checking
		checkspell = CheckSpell;
		CheckSpell = 0;

		// split text into tokens
		nref = SplitText((yyvsp[(1) - (3)]).line, "$mref", (yyvsp[(2) - (3)]).str);
		
		// tag for reference
		tag = (yyvsp[(2) - (3)]).str + 1;

		// output the cross reference jump
		while(nref--)
		{	// get next pointer before cliping white space
			next = strlen(tag) + tag + 1;

			// convert to unifrom white space format
			UniformWhiteSpace(tag);

			// make sure take is not empty
			if( tag[0] == '\0' ) fatalomh(
				"At $mref command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"only white space between two delimiters ",
				"following $mref command",
				NULL
			);
	
			// output the cross reference
			OutputString(" ");
			HrefOutputPass1(tag, "", "false", "");
			OutPre((yyvsp[(2) - (3)]).line, tag);
			HrefEnd("\n");
			
			// search for this cross reference
			C = FindCrossReference(tag, "");
			if( C == NULL )
				C = CreateCrossReference(tag, "", InputName());
			assert( C != NULL );

		       	// next cross reference
			tag = next;
			
			// separator between entries
			if( nref >= 1)
				OutputString(", ");
		}
		
		// restore spell checking to original state
		CheckSpell = checkspell;
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 214:
#line 3598 "omhelp.y"
    {       fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
        ;}
    break;

  case 215:
#line 3601 "omhelp.y"
    {	int ntoken;

		// split text into tokens
		ntoken = SplitText((yyvsp[(1) - (3)]).line, "$navigate", (yyvsp[(2) - (3)]).str);

		// set the current navigation sequence
		SectionNavigate(CurrentSection, ntoken, (yyvsp[(2) - (3)]).str + 1, (yyvsp[(1) - (3)]).line);

		// done with the delimiter sequence
		FreeMem((yyvsp[(2) - (3)]).str);
	;}
    break;

  case 216:
#line 3617 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 217:
#line 3620 "omhelp.y"
    {
		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		if( strlen((yyvsp[(2) - (3)]).str)  > 1 ) fatalomh(
			"More that one character is specified by the\n",
			"$newlinech comamnd in line ",
			int2str((yyvsp[(1) - (3)]).line),
			NULL
		);

		NewlineCh = *((yyvsp[(2) - (3)]).str);
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 218:
#line 3642 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 219:
#line 3645 "omhelp.y"
    {	int pre = 0;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		OutputString("<span style='white-space: nowrap'>");
		outtext((yyvsp[(2) - (3)]).line, (yyvsp[(2) - (3)]).str, pre);
		OutputString("</span>\n");
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 220:
#line 3663 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		CheckSpell = 0;
		PushPending((yyvsp[(1) - (1)]).line, "$nospell");

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 221:
#line 3674 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str == NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		CheckSpell = 1;
		PopPending((yyvsp[(3) - (3)]).line, "$nospell");

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 226:
#line 3694 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 227:
#line 3697 "omhelp.y"
    {	assert( (yyvsp[(1) - (2)]).str != NULL );
		assert( (yyvsp[(2) - (2)]).str == NULL );

		if( PreviousOutputWasHeading )
		{	ConvertForcedNewline(1);
			PreviousOutputWasHeading = 0;
		}

		OutputMath(1, (yyvsp[(1) - (2)]).str, '\0', ItalicCount > 0);	
		
		FreeMem((yyvsp[(1) - (2)]).str);

		(yyval).str  = NULL;
		(yyval).line = (yyvsp[(1) - (2)]).line;
	;}
    break;

  case 228:
#line 3716 "omhelp.y"
    {
		char *path;
		char *ext;
		int ntoken;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		// only use path command at root level
		if( CurrentSection == SectionTree ) 
		{
			// split text into tokens
			ntoken = SplitText((yyvsp[(1) - (3)]).line, "$path", (yyvsp[(2) - (3)]).str);
			if( ntoken != 2 ) fatalomh(
				"At $path comamnd in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\n$path command expects three delimiters",
				NULL
			);
		
			// path token
			path = (yyvsp[(2) - (3)]).str + 1;
	
			// extension token
			ext  = path + strlen(path) + 1;

			InputAddPath(path, ext);
		}

		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 229:
#line 3755 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 230:
#line 3758 "omhelp.y"
    {
		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		// if output begins with a preformatted new line
		// do not need an extra one to for previous heading
		if( PreviousOutputWasHeading )
		{	char *s = (yyvsp[(2) - (3)]).str;
			char ch = *s++;

			int newline = 0;

			while( isspace(ch) )
			{	newline = newline || (ch == '\n');
				ch = *s++;
			}

			if( ! newline )
				ConvertForcedNewline(1);

			PreviousOutputWasHeading = 0;
		}

		// do not put any white space before or after $pre command
		// to aid in text placement on page
		OutputString("<code>");
		OutPre((yyvsp[(2) - (3)]).line, (yyvsp[(2) - (3)]).str);
		OutputString("</code>");
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 231:
#line 3796 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str != NULL );

		if( TableLevel == 0 ) fatalomh(
			"The ",
			(yyvsp[(1) - (1)]).str,
			" command in line ",
			int2str((yyvsp[(1) - (1)]).line),
			"\nis not inside of a table; i.e.,\n",
			"not between a $table and the corresponding $tend",
			NULL
		);
		assert( PreviousOutputWasHeading == 0 );

		OutputString("</td></tr><tr>");
		FormatOutput("<td align='%s' ", HorizontalAlign);
		FormatOutput(" valign='%s'>\n", VerticalAlign);

		PopPending( (yyvsp[(1) - (1)]).line, "$cnext");
		PopPending( (yyvsp[(1) - (1)]).line, "$rnext");
		PushPending((yyvsp[(1) - (1)]).line, "$rnext");
		PushPending((yyvsp[(1) - (1)]).line, "$cnext");

		FreeMem((yyvsp[(1) - (1)]).str);

		(yyval).str   = NULL;
		(yyval).line  = (yyvsp[(1) - (1)]).line;
	;}
    break;

  case 232:
#line 3827 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );
		assert( PreviousOutputWasHeading == 0 );

		(yyval).str = str_alloc("$rend");
		(yyval).line = (yyvsp[(1) - (1)]).line;
	;}
    break;

  case 233:
#line 3834 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );
		assert( PreviousOutputWasHeading == 0 );

		(yyval).str = str_alloc("$rnext");
		(yyval).line = (yyvsp[(1) - (1)]).line;
	;}
    break;

  case 234:
#line 3844 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 235:
#line 3847 "omhelp.y"
    {	assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		Rmark  = *((yyvsp[(2) - (3)]).str);
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 236:
#line 3861 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 237:
#line 3864 "omhelp.y"
    {	char *tag;
		CrossReference *C;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		// this command must be inside of a table
		if( TableLevel == 0 ) fatalomh(
			"The $rref command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nis not inside of a table; i.e.,\n",
			"not between a $table and the corresponding $tend",
			NULL
		);
		assert( PreviousOutputWasHeading == 0 );

		// cross reference tag
		tag = (yyvsp[(2) - (3)]).str;

		// convert to uniform white space format
		UniformWhiteSpace(tag);

		// output the cross reference
		FormatOutput("<RREF=\"%s\">", tag);
			
		// search for this cross reference
		C = FindCrossReference(tag, "");
		if( C == NULL )
			C = CreateCrossReference(tag, "", InputName());
		assert( C != NULL );

		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 238:
#line 3904 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 239:
#line 3907 "omhelp.y"
    {	char *noEscape;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		// I guess some one might put a paragraph heading 
		// for an empty paragraph directly before the section title
		if( PreviousOutputWasHeading )
			PreviousOutputWasHeading = 0;

		// remember the title
		if( CurrentSection->title != NULL ) fatalomh(
			"At $section command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nMore than one $section command between\n",
			"the $begin and $end for the current section",
			NULL
		);

		// version of title without escape characters
		noEscape = str_alloc((yyvsp[(2) - (3)]).str);
		if( MindexSection )
			StrRemove(noEscape, Escape);
		CurrentSection->title = str_alloc(noEscape);
		
		// title for this topic
		SearchTitle(noEscape);

		// erase the current heading setting
		InitializeHeading();

		// add to function reference
		InsertInFunRef(CurrentSection->tag, noEscape);


		// title for this section
		OutputString("<center><b><big><big>");
		if( PrintableOmhelp() )
		{
			char *printid;
			printid = SectionNumber(CurrentSection);

			if( printid[0] != '\0' )
			{
				FormatOutput2(
					"<a name=\"%s\" id=\"%s\">", 
					printid,
					printid
				);
				OutputString(printid);
				OutputString(": ");
				outtext((yyvsp[(2) - (3)]).line, noEscape, 0);
				OutputString("</a>\n");
			}
			else	outtext((yyvsp[(2) - (3)]).line, noEscape, 0);

			FreeMem(printid);
		}
		else	outtext((yyvsp[(2) - (3)]).line, noEscape, 0);
		OutputString("</big></big></b></center>\n");

		// the end of centering starts a new line
		ConvertAddPrevious(1);

		if( MindexSection )
		{	char *lower = StrLowAlloc((yyvsp[(2) - (3)]).str);

			// add keywords to search for this section
			SearchKeywords(lower, Escape);
		
			MultipleIntoIndex(
				lower, 
				CurrentSection->tag, 
				HeadingAndSubHeading(),
				Escape
			);

			FreeMem(lower);
		}

		FreeMem(noEscape);
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 240:
#line 3997 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 241:
#line 4000 "omhelp.y"
    {	fatalomh(
			"At $skipnl in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nThe $skipnl command has been removed from\n",
			"the OMhelp language",
			NULL
		);
	;}
    break;

  case 242:
#line 4012 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		OutputString("<small>");
		PushPending((yyvsp[(1) - (1)]).line, "$small");

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 243:
#line 4023 "omhelp.y"
    {
		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str == NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		OutputString("</small>");
		PopPending((yyvsp[(3) - (3)]).line, "$small");

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 244:
#line 4037 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 245:
#line 4040 "omhelp.y"
    {
		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		if( (yyvsp[(2) - (3)]).str[0] != '\0' )
			SpellingOkList((yyvsp[(2) - (3)]).str);

		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 246:
#line 4056 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 247:
#line 4059 "omhelp.y"
    {	
		CrossReference *C;
		char           *number = NULL;
		char           *printid = NULL;
		char           *noEscape;
		char           *converted;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );
		
		if( TableLevel > 0 ) fatalomh(
			"The $subhead command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			" is inside a table; i.e.,\n",
			"between a $table and the corresponding $tend",
			NULL
		);

 		// make sure no # characters in subheading
 		if( strchr((yyvsp[(2) - (3)]).str, '#') != NULL ) fatalomh(
 			"$head command in line ",
 			int2str((yyvsp[(1) - (3)]).line),
 			" has heading\n",
 			(yyvsp[(2) - (3)]).str,
 			"\nThe character '#' is not allowed in headings",
 			NULL
 		);
 
 		// make sure no # characters in heading
 		if( strchr((yyvsp[(2) - (3)]).str, '#') != NULL ) fatalomh(
 			"$subhead command in line ",
 			int2str((yyvsp[(1) - (3)]).line),
 			" has subheading\n",
 			(yyvsp[(2) - (3)]).str,
			"\nThe character '#' is not allowed in headings",
 			NULL
 		);

		if( ConvertPreviousNewline() < 2 )
			ConvertForcedNewline(2 - ConvertPreviousNewline() );

		// version of heading without escape characters
		noEscape = str_alloc((yyvsp[(2) - (3)]).str);
		if( MindexSubhead )
			StrRemove(noEscape, Escape);

		// convert to unifrom white space format
		UniformWhiteSpace(noEscape);

		// set corresponding current heading
		SetSubHeading(noEscape);

		number  = SectionNumber(CurrentSection);
		assert( *( HeadingAndSubPrintId() ) == '.' );
		if( number[0] == '\0' )
			printid = strjoin(number, HeadingAndSubPrintId()+1);
		else	printid = strjoin(number, HeadingAndSubPrintId() );

		OutputString("<b>");
		if( PrintableOmhelp() )
		{	FormatOutput2(
				"<a name=\"%s\" id=\"%s\">", 
				printid,
				printid
			);
			OutputString(printid);
			OutputString(": ");
		}
		else
		{	converted = ConvertInternalString(
				HeadingAndSubHeading()
			);
			FormatOutput2(
				"<a name=\"%s\" id=\"%s\">", 
				converted,
				converted
			);
			FreeMem(converted);
		}

		outtext((yyvsp[(2) - (3)]).line, noEscape, 0);
		OutputString("</a></b>\n");

		// defined cross reference point
		C = DefineCrossReference(
			CurrentSection->tag, 
			HeadingAndSubHeading(),
			InputName(),
			iFrame,
			printid
		);
		assert( C != NULL );
		FreeMem(number);
		FreeMem(printid);

		if( MindexSubhead )
		{	char *lower = StrLowAlloc((yyvsp[(2) - (3)]).str);

			// add keywords to search for this section
			SearchKeywords(lower, Escape);
		
			MultipleIntoIndex(
				lower, 
				CurrentSection->tag, 
				HeadingAndSubHeading(),
				Escape
			);

			FreeMem(lower);
		}

		FreeMem(noEscape);
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);

		PreviousOutputWasHeading = 1;
	;}
    break;

  case 248:
#line 4182 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 249:
#line 4185 "omhelp.y"
    {	char *token;
		char *next;
		int  count;
		int  ntoken;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		// split text into tokens
		ntoken = SplitText((yyvsp[(1) - (3)]).line, "$syntax", (yyvsp[(2) - (3)]).str);

		// first token
		token = (yyvsp[(2) - (3)]).str + 1;
		
		// initialize delimter count flag
		count  = 1;

		// if output begins with a preformatted new line
		// do not need an extra one to for previous heading
		if( PreviousOutputWasHeading )
		{	char *s = token;
			char ch = *s++;

			int newline = 0;

			while( isspace(ch) )
			{	newline = newline || (ch == '\n');
				ch = *s++;
			}

			if( ! newline )
				ConvertForcedNewline(1);

			PreviousOutputWasHeading = 0;
		}
		

		// for each token
		while( ntoken-- )
		{	next = token + strlen(token) + 1;
			if( count % 2 == 0 )
			{	OutputString("<i>");
				ClipWhiteSpace(token);
				outtext((yyvsp[(2) - (3)]).line, token, 1);
				OutputString("</i>");
			}
			else
			{	// code font
				OutputString("<code><font color=\"");
				OutputString(CodeColor);
				OutputString("\">");
				outtext((yyvsp[(2) - (3)]).line, token, 1);
				OutputString("</font></code>");
			}
			count++;
			token = next;
		}
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 250:
#line 4252 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		// do not need extra new line after previous heading
		if( PreviousOutputWasHeading )
			PreviousOutputWasHeading = 0;

		TableLevel++;	

		OutputString("<table><tr>");
		FormatOutput("<td align='%s' ", HorizontalAlign);
		FormatOutput(" valign='%s'>\n", VerticalAlign);

		PushPending((yyvsp[(1) - (1)]).line, "$table");
		PushPending((yyvsp[(1) - (1)]).line, "$rnext");
		PushPending((yyvsp[(1) - (1)]).line, "$cnext");


		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 251:
#line 4275 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 252:
#line 4278 "omhelp.y"
    {	int size;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		size = atoi((yyvsp[(2) - (3)]).str);
		if( size >= 100 ) fatalomh(
			"In $tabsize command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nnumber of columns is greater than 99",
			NULL
		);
		if( size < 0 ) fatalomh(
			"In $tabsize command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nnumber of columns is less than zero",
			NULL
		);
		if( size == 0 )
			size = TAB_SIZE;

		ConvertSetTabSize(size);

		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 253:
#line 4311 "omhelp.y"
    {	assert( (yyvsp[(1) - (1)]).str == NULL );

		if( TableLevel <= 0 ) fatalomh(
			"There is no matching $table command preceeding\n",
			"the $tend command in line ",
			int2str((yyvsp[(1) - (1)]).line),
			NULL
		);
		assert( PreviousOutputWasHeading == 0 );

		TableLevel--;
		OutputString("</td></tr>\n</table>\n");

		// tables had an automatic new line after them
		// (avoid adding more than once when tables are nested)
		if( TableLevel == 0 )
			ConvertAddPrevious(1);

		PopPending((yyvsp[(1) - (1)]).line, "$cnext");
		PopPending((yyvsp[(1) - (1)]).line, "$rnext");
		PopPending((yyvsp[(1) - (1)]).line, "$table");
	;}
    break;

  case 254:
#line 4336 "omhelp.y"
    {	assert ( (yyvsp[(1) - (1)]).str != NULL );

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 255:
#line 4344 "omhelp.y"
    {	int line = (yyvsp[(1) - (1)]).line;
		char *p = (yyvsp[(1) - (1)]).str;
		char *q = (yyvsp[(1) - (1)]).str;

		assert( (yyvsp[(1) - (1)]).str != NULL );
		assert( REGISTERED_TRADE_MARK_CHARACTER < 5 );
		assert( COPYRIGHT_CHARACTER < 5 );

		// convert special characters 
		while(*p != '\0' )
		{	
			// error cases
			if( *p < 5 ) fatalomh(
				"Line ",
				int2str(line),
				" contains a character with ascii code\n",
				int2str(*p),
				" which is less than 5.",
				NULL
			);

			// conversion cases
			if( *p == Dollar )
				*p = '$';
			if( *p == Rmark )
				*p = REGISTERED_TRADE_MARK_CHARACTER;
			if( *p == Cmark )
				*p = COPYRIGHT_CHARACTER;
			if( *p == Wspace )
				*p = ' ';

			if( *p == '\n' )
			{	// increment line counter
				line++;
				p++;
				q++;
				*p = *q;
				if( *p != '\0' && *p == NewlineCh )
				{	// skip program source comment char
					q++;
					*p = *q;
					// skip one space character (if present)
					if( *p == ' ' )
					{	q++;
						*p = *q;
					}
				}
			}
			else
			{	p++;
				q++;
				*p = *q;
			}
		}

		(yyval) = (yyvsp[(1) - (1)]);
	;}
    break;

  case 256:
#line 4404 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 257:
#line 4407 "omhelp.y"
    {
		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		// only one $textcolor per section
		if( CurrentSection->style.textcolor != NULL ) fatalomh(
			"At $textcolor comamnd in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nThere is more than one $textcolor command ",
			"in this section.",
			NULL
		);


		CurrentSection->style.textcolor = Color(
			(yyvsp[(1) - (3)]).line, "$textcolor", (yyvsp[(2) - (3)]).str
		);
		
		FreeMem((yyvsp[(2) - (3)]).str);
		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 258:
#line 4433 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 259:
#line 4436 "omhelp.y"
    {
		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		if( PreviousOutputWasHeading )
		{	ConvertForcedNewline(1);
			PreviousOutputWasHeading = 0;
		}

		// output the index in italic followed by "-th"
		OutputString("<i>");
		outtext((yyvsp[(2) - (3)]).line, (yyvsp[(2) - (3)]).str, 0);
		OutputString("</i>");
		OutputString("-th");
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 260:
#line 4461 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 261:
#line 4464 "omhelp.y"
    {
		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		printf("%s", (yyvsp[(2) - (3)]).str);
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 262:
#line 4477 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 263:
#line 4480 "omhelp.y"
    {	char *tag = (yyvsp[(2) - (3)]).str;
		CrossReference *C;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		if( PreviousOutputWasHeading )
		{	ConvertForcedNewline(1);
			PreviousOutputWasHeading = 0;
		}

		// output the cross reference
		FormatOutput("<TITLE=\"%s\">", tag);
			
		// search for this cross reference
		C = FindCrossReference(tag, "");
		if( C == NULL )
			C = CreateCrossReference(tag, "", InputName());
		assert( C != NULL );

		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 264:
#line 4509 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 265:
#line 4512 "omhelp.y"
    {	char *tag;
		CrossReference *C;
		
		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		if( PreviousOutputWasHeading )
		{	// place a new line after heading and before title
			ConvertForcedNewline(1);

			// there is no pass one output in title, so need
			// to cancel new line counter for previous newline
			ConvertAddPrevious(-1);

			// title is not a heading
			PreviousOutputWasHeading = 0;
		}

		// cross reference tag
		tag = (yyvsp[(2) - (3)]).str;

		// convert to uniform white space format
		UniformWhiteSpace(tag);

		// output the cross reference
		FormatOutput("<TREF=\"%s\">", tag);
			
		// search for this cross reference
		C = FindCrossReference(tag, "");
		if( C == NULL )
			C = CreateCrossReference(tag, "", InputName());
		assert( C != NULL );

		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 266:
#line 4555 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 267:
#line 4558 "omhelp.y"
    {	char *root;
		char *ext;
		char *filename;
		char *start;
		char *stop;
		char ch;
		char previous;
		int  skip;
		int  ntoken;
		int  nspace;
		int  match;
		int  len;
		int  i;

		// initialize token to avoid warning
		// (compiler does not know fatalerr will not return)
		char *token = NULL;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		ntoken = SplitText((yyvsp[(1) - (3)]).line, "$verbatim", (yyvsp[(2) - (3)]).str);
		if( 5 < ntoken ) fatalomh(
			"At $verbatim command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nMore than 6 delimiters in $verbatim command",
			NULL
		);

		filename = (yyvsp[(2) - (3)]).str + 1;
		if( ntoken < 2 )
			nspace = 0;
		else
		{	token = filename + strlen(filename) + 1;
			nspace = atoi(token);
		}
		if( ntoken < 3 )
			start = "\0";
		else	start = token + strlen(token) + 1;
		if( ntoken < 4 )
			stop  = "\0";
		else	stop  = start + strlen(start) + 1;
		if( ntoken < 5 )
			skip  = 0;
		else
		{	token = stop + strlen(stop) + 1;
			skip  = atoi(token);
		}

		ClipWhiteSpace(filename);
		InputSplitName(&root, &ext, filename);
		InputPush(root, ext, -1);

		if( ntoken < 3 ) 
		{	
			if( ConvertPreviousNewline() < 1 )
			{	ConvertForcedNewline(1);
				PreviousOutputWasHeading = 0;
			}

			previous = '\n';
		}
		else	previous = '\0';

		if( PreviousOutputWasHeading )
		{	ConvertForcedNewline(1);
			PreviousOutputWasHeading = 0;
		}

		// initialize with first character
		ch       = InputGet();

		// skip to starting point
		len = PatternMatchLen(start, Escape);
		if( len == -1 )
		{	InputPop();
			fatalomh(
				"At $verbatim command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\nToo many characters in start pattern",
				NULL
			);
		}
		if( len == -2 )
		{	InputPop();
			fatalomh(
				"At $verbatim command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\nThree decimal digits must follow the ",
				"escape character in the start pattern",
				NULL
			);
		}
		assert( len >= 0 );
		if( len > 0 )
		{
			match = 0;
			while( (! match)  & (ch != '\001') )
			{	match = PatternMatchCh(&ch);
				if( match && skip > 0 )
				{	--skip;
					match = 0;
				}
				ch = InputGet();
			}

			if( ch == '\001' )
			{	InputPop();
				fatalomh(
					"At $verbatim command in line ",
					int2str((yyvsp[(1) - (3)]).line),
					"\nCould not find the start pattern \"",
					start,
					"\"\nin the file ",
					filename,
					NULL
				);
			}
		}

		len     = PatternMatchLen(stop, Escape);
		if( len == -1 )
		{	InputPop();
			fatalomh(
				"At $verbatim command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\nToo many characters in stop pattern",
				NULL
			);
		}
		if( len == -2 )
		{	InputPop();
			fatalomh(
				"At $verbatim command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\nThree decimal digits must follow the ",
				"escape character in the stop pattern",
				NULL
			);
		}

		// a standard compliant way to inhibit line breaks at 
		// '-' in MS Internet Explorer (should not be necessary)
		OutputString("<span style='white-space: nowrap'>");

		match = 0;
		while(ch != '\001' )
		{
			if( len > 0 )
				match = PatternMatchCh(&ch);

			// indent when previous character is a newline
			if( previous == '\n' )
			{	// need not indent lines with only white space
				if( ! isspace(ch) && ! (ch == '\001') )
				{	previous = ch;
					for(i = 0; i < nspace; i++)
						ConvertOutputCh(' ', 1);
				}
			}
			else	previous = ch;

			if( (ch != '\001') & (ch != '\0') )
				ConvertOutputCh(ch, 1);

			// check for stopping point after outputing ch
			if( match )
				ch = '\001';

			if( ch != '\001' )
				ch = InputGet();
		}

		// stop preformatted output
		OutputString("</span>");

		
		if( ntoken < 3  )
		{	if( ConvertPreviousNewline() < 1 )
				ConvertForcedNewline(1);
		}

		InputPop();

		if( len > 0 && ! match ) fatalomh(
			"At $verbatim command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nCould not find the stop pattern \"",
			stop,
			"\"\nin the file ",
			filename,
			NULL
		);
		
		FreeMem(root);
		FreeMem(ext);
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 268:
#line 4763 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 269:
#line 4766 "omhelp.y"
    {
		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		Wspace = *((yyvsp[(2) - (3)]).str);
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;

  case 270:
#line 4781 "omhelp.y"
    {	fatal_not_2_dollar_or_text((yyvsp[(1) - (3)]).code, (yyvsp[(1) - (3)]).line, (yyvsp[(3) - (3)]).code);
	;}
    break;

  case 271:
#line 4784 "omhelp.y"
    {	char *tag;
		char *head;
		char *subhead;
		char *link;
		char *frame;
		CrossReference *C;

		int checkspell;
		int ntoken;
		int i, j;

		assert( (yyvsp[(1) - (3)]).str == NULL );
		assert( (yyvsp[(2) - (3)]).str != NULL );
		assert( (yyvsp[(3) - (3)]).str == NULL );

		if( PreviousOutputWasHeading )
		{	ConvertForcedNewline(1);
			PreviousOutputWasHeading = 0;
		}
		
		// initial state of spell checker
		checkspell = CheckSpell;

		// split text into tokens
		ntoken = SplitText((yyvsp[(1) - (3)]).line, "$xref", (yyvsp[(2) - (3)]).str);
		if( ntoken > 5 ) fatalomh(
			"At $xref command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nMore than 6 delimiters in $xref command",
			NULL
		);
		
		// tag for reference
		tag = (yyvsp[(2) - (3)]).str + 1;

		// determine which arguments are present
		head    = "";
		subhead = "";
		link    = "";
		frame   = "";
		if( ntoken == 5 )
		{	head    = tag     + strlen(tag)     + 1;
			subhead = head    + strlen(head)    + 1;
			link    = subhead + strlen(subhead) + 1;
			frame   = link    + strlen(link)    + 1;
		}
		else if( ntoken > 1 )
		{	head = tag + strlen(tag) + 1;
			if( ntoken > 2 )
				link = head + strlen(head) + 1;
			if( ntoken > 3 )
				frame = link + strlen(link) + 1;
		}

		// convert to unifrom white space format
		UniformWhiteSpace(tag);
		UniformWhiteSpace(head);
		UniformWhiteSpace(subhead);
		UniformWhiteSpace(link);
		UniformWhiteSpace(frame);

		// make sure tag is not empty
		if( tag[0] == '\0' ) fatalomh(
			"At $xref command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nOnly white space between first 2 delimiters",
			NULL
		);


		// check the frame specification
		if( ntoken >= 4  )
		{
			if( frame[0] == '\0' ) fatalomh(
				"At $xref command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\nFrame number in $xref command is empty; ",
				"i.e., just white space.",
				NULL
			);

			i     = atoi(frame);
			if( i < 1 ) fatalomh(
				"At $xref command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\nFrame number in $xref command is ",
				"less than 1",
				NULL
			);

			if( i > MaxFrame )
			{	FreeMem( MaxFrameFile );
				MaxFrame = i;
				MaxFrameLine = (yyvsp[(1) - (3)]).line;
				MaxFrameFile = str_alloc(InputName());
			}

			if( head[0] == '\0' ) fatalomh(
				"At $xref command in line ",
				int2str((yyvsp[(1) - (3)]).line),
				"\nCannot have an empty heading",
				"\nwhen a particular frame is specified.",
				NULL
			);
		} 

		// if subheading is specified, check that heading is not empty
		if( subhead[0] != '\0' && head[0] == '\0' ) fatalomh(
			"At $xref command in line ",
			int2str((yyvsp[(1) - (3)]).line),
			"\nCannot have an empty heading with ",
			"a non-empty subheading.",
			NULL
		);

		// attach the subheading to the heading
		if( subhead[0] != '\0' )
		{	i         = strlen(head);
			j         = 0;
			head[i++] = '.';
			while( subhead[j] != '\0' )
			{	assert( head + i < link - 1 );
				head[i++] = subhead[j++];	
			}
			head[i] = '\0';
		}

		// if linking text is empty or not present
		// use the tag for the linking text
		if( link[0] == '\0' )
			link = tag;

		// if frame is not present and heading is not empty
		// change frame to 1
		if( ntoken < 4 && head[0] != '\0' )
			frame = "1";

		if( PrintableOmhelp() | NoFrame() )
		{	frame = "";
			MaxFrame = 0;
		}

		// output the cross reference jump without spell checking
		CheckSpell = 0;
		HrefOutputPass1(tag, head, "false", frame);

		// do not check spelling on cross reference tags
		if( ntoken > 2 )
			CheckSpell = checkspell;
		
		OutPre((yyvsp[(2) - (3)]).line, link);
		HrefEnd("\n");
		
		// search for this cross reference
		C = FindCrossReference(tag, head);
		if( C == NULL )
			C = CreateCrossReference(tag, head, InputName());
		assert( C != NULL );

		// restore spell checking to initial setting
		CheckSpell = checkspell;
		
		FreeMem((yyvsp[(2) - (3)]).str);

		(yyval) = (yyvsp[(1) - (3)]);
	;}
    break;


/* Line 1267 of yacc.c.  */
#line 7139 "omhelp.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 4951 "omhelp.y"


